package net.sourceforge.x360mediaserve.upnpmediaserver.upnp.cybergarage;


import java.io.InputStream;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;

import org.cybergarage.http.HTTPHeader;
import org.cybergarage.upnp.control.ActionRequest;

public class HTTPServletRequestWrapper {
	private byte[] content;
	Vector httpHeaders;	
	
	public HTTPServletRequestWrapper(HttpServletRequest req){
		try{
			httpHeaders=new Vector();
			
			InputStream inputstream=req.getInputStream();
			content=new byte[req.getContentLength()];
			for(int i=0;i<req.getContentLength();i++){
				content[i]=(byte)inputstream.read();
			}
			
			
			Enumeration headernames=req.getHeaderNames();

			while(headernames.hasMoreElements()){
				String headername=(String)headernames.nextElement();
				httpHeaders.add(new HTTPHeader(headername,req.getHeader(headername)));
			}
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	
	// hopefully this is enough to make the action request work
	public ActionRequest getActionRequest(){
		ActionRequest result=new ActionRequest();
		result.setContent(content);
		
		Iterator i=httpHeaders.iterator();
		
		while(i.hasNext())
		{
			
			result.addHeader((HTTPHeader)i.next());
			
		}
		
		return result;
	}	
	
}
