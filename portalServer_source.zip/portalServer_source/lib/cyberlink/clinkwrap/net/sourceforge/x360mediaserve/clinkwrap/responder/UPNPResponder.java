/******************************************************************
*
*	MediaServer for CyberLink
*
*	Copyright (C) Satoshi Konno 2003
*
*	File : MediaServer.java
*
*	10/22/03
*		- first revision.
*	03/30/05
*		- Added a constructor that read the description from memory instead of the file.
*		- Changed it as the default constructor.
*
******************************************************************/

package net.sourceforge.x360mediaserve.clinkwrap.responder;

import java.io.File;

import org.cybergarage.http.HTTPRequest;
import org.cybergarage.net.HostInterface;
import org.cybergarage.upnp.UPnP;
import org.cybergarage.upnp.device.InvalidDescriptionException;
import org.cybergarage.upnp.device.ST;
import org.cybergarage.upnp.ssdp.SSDPPacket;
import org.cybergarage.util.Debug;

public class UPNPResponder extends UPNPListener
{
	////////////////////////////////////////////////
	// Constants
	////////////////////////////////////////////////
	
	public final static String DEVICE_TYPE = "urn:schemas-upnp-org:device:MediaServer:1";
	
	public final static int DEFAULT_HTTP_PORT = 4242;

	
	
public static final String DESCRIPTION = "<?xml version=\"1.0\"?>\n"+
"<root xmlns=\"urn:schemas-upnp-org:device-1-0\">\n"+
"<specVersion>\n"+
"<major>1</major>\n"+
"<minor>0</minor>\n"+
"</specVersion>\n"+
"<device>\n"+
"<UDN>uuid:492a4242-22c2-25b1-a112-4c7ac45678a1</UDN>\n"+
"<friendlyName>x360mediaserve: 1 : Windows Media Connect</friendlyName>\n"+
"<deviceType>urn:schemas-upnp-org:device:MediaServer:1</deviceType>\n"+
"<manufacturer>Tawsi</manufacturer>\n"+
"<manufacturerURL>http://x360mediaserve.sf.net/</manufacturerURL>\n"+
"<modelName>Windows Media Connect</modelName>\n"+
"<modelNumber>2.0</modelNumber>\n"+
"<modelURL>http://x360mediaserve.sf.net</modelURL>\n"+
"<serialNumber>{1}</serialNumber>\n"+
"<serviceList>\n"+
"<service>\n"+
"<serviceType>urn:schemas-upnp-org:service:ConnectionManager:1</serviceType>\n"+
"<serviceId>urn:upnp-org:serviceId:ConnectionManager</serviceId>\n"+
"<SCPDURL>/service/ConnectionManager1.xml</SCPDURL>\n"+
"<controlURL>/service/ConnectionManager_control</controlURL>\n"+
"<eventSubURL>/service/ConnectionManager_event</eventSubURL>\n"+
"</service>\n"+
"<service>\n"+
"<serviceType>urn:schemas-upnp-org:service:ContentDirectory:1</serviceType>\n"+
"<serviceId>urn:upnp-org:serviceId:ContentDirectory</serviceId>\n"+
"<SCPDURL>/service/ContentDirectory1.xml</SCPDURL>\n"+
"<controlURL>/service/ContentDirectory/Control</controlURL>\n"+
"<eventSubURL>/service/ContentDirectory/Event</eventSubURL>\n"+
"</service>\n"+
"<service>\n"+
"<serviceType>urn:microsoft.com:service:X_MS_MediaReceiverRegistrar:1</serviceType>\n"+
"<serviceId>urn:microsoft.com:serviceId:X_MS_MediaReceiverRegistrar</serviceId>\n"+
"<SCPDURL>/service/MediaReceiverRegistrar/MediaReceiverRegistrar1.xml</SCPDURL>"+
"<eventSubURL>/service/MediaReceiverRegistrar/Event</eventSubURL>"+
"<controlURL>/service/MediaReceiverRegistrar/Control</controlURL>"+
"</service>\n"+
"</serviceList>\n"+
"</device>\n"+"</root>";
public final static String MEDIA_RECEIVER_REGISTRAR_SERVICE_TYPE = "urn:microsoft.com:service:X_MS_MediaReceiverRegistrar:1";

public final static String MEDIA_RECEIVER_REGISTRAR_SCPD = 
	"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
	"<scpd xmlns=\"urn:schemas-upnp-org:service-1-0\">\n" +
	"   <specVersion>\n" +
	"      <major>1</major>\n" +
	"      <minor>0</minor>\n" +
	"	</specVersion>\n" +
	"	<actionList>\n" +
	"		<action>\n" +
	"         <name>IsAuthorized</name>\n" +
	"         <argumentList>\n" +
	"            <argument>\n" +
	"               <name>DeviceID</name>\n" +
	"               <direction>in</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_DeviceID</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>Result</name>\n" +
	"               <direction>out</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_Result</relatedStateVariable>\n" +
	"            </argument>\n" +
	"         </argumentList>\n" +
	"      </action>\n" +
	"      <action>\n" +
	"         <name>RegisterDevice</name>\n" +
	"         <argumentList>\n" +
	"            <argument>\n" +
	"               <name>RegistrationReqMsg</name>\n" +
	"               <direction>in</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_RegistrationReqMsg</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>RegistrationRespMsg</name>\n" +
	"               <direction>out</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_RegistrationRespMsg</relatedStateVariable>\n" +
	"            </argument>\n" +
	"         </argumentList>\n" +
	"      </action>\n" +
	"      <action>\n" +
	"         <name>IsValidated</name>\n" +
	"         <argumentList>\n" +
	"            <argument>\n" +
	"               <name>DeviceID</name>\n" +
	"               <direction>in</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_DeviceID</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>Result</name>\n" +
	"               <direction>out</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_Result</relatedStateVariable>\n" +
	"            </argument>\n" +
	"         </argumentList>\n" +
	"      </action>\n" +
	"   </actionList>\n" +
	"   <serviceStateTable>\n" +
	"      <stateVariable sendEvents=\"no\">\n" +
	"         <name>A_ARG_TYPE_DeviceID</name>\n" +
	"         <dataType>string</dataType>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"no\">\n" +
	"         <name>A_ARG_TYPE_Result</name>\n" +
	"         <dataType>int</dataType>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"no\">\n" +
	"         <name>A_ARG_TYPE_RegistrationReqMsg</name>\n" +
	"         <dataType>bin.base64</dataType>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"no\">\n" +
	"         <name>A_ARG_TYPE_RegistrationRespMsg</name>\n" +
	"         <dataType>bin.base64</dataType>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"no\">\n" +
	"         <name>AuthorizationGrantedUpdateID</name>\n" +
	"         <dataType>ui4</dataType>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"no\">\n" +
	"         <name>AuthorizationDeniedUpdateID</name>\n" +
	"         <dataType>ui4</dataType>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"no\">\n" +
	"         <name>ValidationSucceededUpdateID</name>\n" +
	"         <dataType>ui4</dataType>\n" +
	"      </stateVariable>\n" +		
	"      <stateVariable sendEvents=\"no\">\n" +
	"         <name>ValidationRevokedUpdateID</name>\n" +
	"         <dataType>ui4</dataType>\n" +
	"      </stateVariable>\n" +			
	"   </serviceStateTable>\n" +
	"</scpd>";	
public final static String CONNECTION_MANAGER_SERVICE_TYPE = "urn:schemas-upnp-org:service:ConnectionManager:1";
public final static String CONNECTION_MANAGER_SCPD = 
	"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
	"<scpd xmlns=\"urn:schemas-upnp-org:service-1-0\">\n" +
	"   <specVersion>\n" +
	"      <major>1</major>\n" +
	"      <minor>0</minor>\n" +
	"	</specVersion>\n" +
	"	<actionList>\n" +
	"		<action>\n" +
	"         <name>GetCurrentConnectionInfo</name>\n" +
	"         <argumentList>\n" +
	"            <argument>\n" +
	"               <name>ConnectionID</name>\n" +
	"               <direction>in</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_ConnectionID</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>RcsID</name>\n" +
	"               <direction>out</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_RcsID</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>AVTransportID</name>\n" +
	"               <direction>out</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_AVTransportID</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>ProtocolInfo</name>\n" +
	"               <direction>out</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_ProtocolInfo</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>PeerConnectionManager</name>\n" +
	"               <direction>out</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_ConnectionManager</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>PeerConnectionID</name>\n" +
	"               <direction>out</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_ConnectionID</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>Direction</name>\n" +
	"               <direction>out</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_Direction</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>Status</name>\n" +
	"               <direction>out</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_ConnectionStatus</relatedStateVariable>\n" +
	"            </argument>\n" +
	"         </argumentList>\n" +
	"      </action>\n" +
	"      <action>\n" +
	"         <name>GetProtocolInfo</name>\n" +
	"         <argumentList>\n" +
	"            <argument>\n" +
	"               <name>Source</name>\n" +
	"               <direction>out</direction>\n" +
	"               <relatedStateVariable>SourceProtocolInfo</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>Sink</name>\n" +
	"               <direction>out</direction>\n" +
	"               <relatedStateVariable>SinkProtocolInfo</relatedStateVariable>\n" +
	"            </argument>\n" +
	"         </argumentList>\n" +
	"      </action>\n" +
	"      <action>\n" +
	"         <name>GetCurrentConnectionIDs</name>\n" +
	"         <argumentList>\n" +
	"            <argument>\n" +
	"               <name>ConnectionIDs</name>\n" +
	"               <direction>out</direction>\n" +
	"               <relatedStateVariable>CurrentConnectionIDs</relatedStateVariable>\n" +
	"            </argument>\n" +
	"         </argumentList>\n" +
	"      </action>\n" +
	"   </actionList>\n" +
	"   <serviceStateTable>\n" +
	"      <stateVariable sendEvents=\"no\">\n" +
	"         <name>A_ARG_TYPE_ProtocolInfo</name>\n" +
	"         <dataType>string</dataType>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"no\">\n" +
	"         <name>A_ARG_TYPE_ConnectionStatus</name>\n" +
	"         <dataType>string</dataType>\n" +
	"         <allowedValueList>\n" +
	"            <allowedValue>OK</allowedValue>\n" +
	"            <allowedValue>ContentFormatMismatch</allowedValue>\n" +
	"            <allowedValue>InsufficientBandwidth</allowedValue>\n" +
	"            <allowedValue>UnreliableChannel</allowedValue>\n" +
	"            <allowedValue>Unknown</allowedValue>\n" +
	"         </allowedValueList>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"no\">\n" +
	"         <name>A_ARG_TYPE_AVTransportID</name>\n" +
	"         <dataType>i4</dataType>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"no\">\n" +
	"         <name>A_ARG_TYPE_RcsID</name>\n" +
	"         <dataType>i4</dataType>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"no\">\n" +
	"         <name>A_ARG_TYPE_ConnectionID</name>\n" +
	"         <dataType>i4</dataType>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"no\">\n" +
	"         <name>A_ARG_TYPE_ConnectionManager</name>\n" +
	"         <dataType>string</dataType>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"yes\">\n" +
	"         <name>SourceProtocolInfo</name>\n" +
	"         <dataType>string</dataType>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"yes\">\n" +
	"         <name>SinkProtocolInfo</name>\n" +
	"         <dataType>string</dataType>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"no\">\n" +
	"         <name>A_ARG_TYPE_Direction</name>\n" +
	"         <dataType>string</dataType>\n" +
	"         <allowedValueList>\n" +
	"            <allowedValue>Input</allowedValue>\n" +
	"            <allowedValue>Output</allowedValue>\n" +
	"         </allowedValueList>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"yes\">\n" +
	"         <name>CurrentConnectionIDs</name>\n" +
	"         <dataType>string</dataType>\n" +
	"      </stateVariable>\n" +
	"   </serviceStateTable>\n" +
	"</scpd>";

public final static String CONTENT_DIRECTORY_SERVICE_TYPE = "urn:schemas-upnp-org:service:ContentDirectory:1";
public final static String CONTENT_DIRECTORY_SCPD = 
	"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" + 
	"<scpd xmlns=\"urn:schemas-upnp-org:service-1-0\">\n" + 
	"   <specVersion>\n" + 
	"      <major>1</major>\n" + 
	"      <minor>0</minor>\n" + 
	"   </specVersion>\n" + 
	"   <actionList>\n" + 
	"      <action>\n" + 
	"         <name>ExportResource</name>\n" + 
	"         <argumentList>\n" + 
	"            <argument>\n" + 
	"               <name>SourceURI</name>\n" + 
	"               <direction>in</direction>\n" + 
	"               <relatedStateVariable>A_ARG_TYPE_URI</relatedStateVariable>\n" + 
	"            </argument>\n" + 
	"            <argument>\n" + 
	"               <name>DestinationURI</name>\n" + 
	"               <direction>in</direction>\n" + 
	"               <relatedStateVariable>A_ARG_TYPE_URI</relatedStateVariable>\n" + 
	"            </argument>\n" + 
	"            <argument>\n" + 
	"               <name>TransferID</name>\n" + 
	"               <direction>out</direction>\n" + 
	"               <relatedStateVariable>A_ARG_TYPE_TransferID</relatedStateVariable>\n" + 
	"            </argument>\n" + 
	"         </argumentList>\n" + 
	"      </action>\n" + 
	"      <action>\n" + 
	"         <name>StopTransferResource</name>\n" + 
	"         <argumentList>\n" + 
	"            <argument>\n" + 
	"               <name>TransferID</name>\n" + 
	"               <direction>in</direction>\n" + 
	"               <relatedStateVariable>A_ARG_TYPE_TransferID</relatedStateVariable>\n" + 
	"            </argument>\n" + 
	"         </argumentList>\n" + 
	"      </action>\n" + 
	"      <action>\n" + 
	"         <name>DestroyObject</name>\n" + 
	"         <argumentList>\n" + 
	"            <argument>\n" + 
	"               <name>ObjectID</name>\n" + 
	"               <direction>in</direction>\n" + 
	"               <relatedStateVariable>A_ARG_TYPE_ObjectID</relatedStateVariable>\n" + 
	"            </argument>\n" + 
	"         </argumentList>\n" + 
	"      </action>\n" + 
	"      <action>\n" + 
	"         <name>DeleteResource</name>\n" + 
	"         <argumentList>\n" + 
	"            <argument>\n" + 
	"               <name>ResourceURI</name>\n" + 
	"               <direction>in</direction>\n" + 
	"               <relatedStateVariable>A_ARG_TYPE_URI</relatedStateVariable>\n" + 
	"            </argument>\n" + 
	"         </argumentList>\n" + 
	"      </action>\n" + 
	"      <action>\n" + 
	"         <name>UpdateObject</name>\n" + 
	"         <argumentList>\n" + 
	"            <argument>\n" + 
	"               <name>ObjectID</name>\n" + 
	"               <direction>in</direction>\n" + 
	"               <relatedStateVariable>A_ARG_TYPE_ObjectID</relatedStateVariable>\n" + 
	"            </argument>\n" + 
	"            <argument>\n" + 
	"               <name>CurrentTagValue</name>\n" + 
	"               <direction>in</direction>\n" + 
	"               <relatedStateVariable>A_ARG_TYPE_TagValueList</relatedStateVariable>\n" + 
	"            </argument>\n" + 
	"            <argument>\n" + 
	"               <name>NewTagValue</name>\n" + 
	"               <direction>in</direction>\n" + 
	"               <relatedStateVariable>A_ARG_TYPE_TagValueList</relatedStateVariable>\n" + 
	"            </argument>\n" + 
	"         </argumentList>\n" + 
	"      </action>\n" + 
	"      <action>\n" + 
	"         <name>Browse</name>\n" + 
	"         <argumentList>\n" + 
	"            <argument>\n" + 
	"               <name>ObjectID</name>\n" + 
	"               <direction>in</direction>\n" + 
	"               <relatedStateVariable>A_ARG_TYPE_ObjectID</relatedStateVariable>\n" + 
	"            </argument>\n" + 
	"            <argument>\n" + 
	"               <name>BrowseFlag</name>\n" + 
	"               <direction>in</direction>\n" + 
	"               <relatedStateVariable>A_ARG_TYPE_BrowseFlag</relatedStateVariable>\n" + 
	"            </argument>\n" + 
	"            <argument>\n" + 
	"               <name>Filter</name>\n" + 
	"               <direction>in</direction>\n" + 
	"               <relatedStateVariable>A_ARG_TYPE_Filter</relatedStateVariable>\n" + 
	"            </argument>\n" + 
	"            <argument>\n" + 
	"               <name>StartingIndex</name>\n" + 
	"               <direction>in</direction>\n" + 
	"               <relatedStateVariable>A_ARG_TYPE_Index</relatedStateVariable>\n" + 
	"            </argument>\n" + 
	"            <argument>\n" + 
	"               <name>RequestedCount</name>\n" +
	"               <direction>in</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_Count</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>SortCriteria</name>\n" +
	"               <direction>in</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_SortCriteria</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>Result</name>\n" +
	"               <direction>out</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_Result</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>NumberReturned</name>\n" +
	"               <direction>out</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_Count</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>TotalMatches</name>\n" +
	"               <direction>out</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_Count</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>UpdateID</name>\n" +
	"               <direction>out</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_UpdateID</relatedStateVariable>\n" +
	"            </argument>\n" +
	"         </argumentList>\n" +
	"      </action>\n" +
	"      <action>\n" +
	"         <name>GetTransferProgress</name>\n" +
	"         <argumentList>\n" +
	"            <argument>\n" +
	"               <name>TransferID</name>\n" +
	"               <direction>in</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_TransferID</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>TransferStatus</name>\n" +
	"               <direction>out</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_TransferStatus</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>TransferLength</name>\n" +
	"               <direction>out</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_TransferLength</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>TransferTotal</name>\n" +
	"               <direction>out</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_TransferTotal</relatedStateVariable>\n" +
	"            </argument>\n" +
	"         </argumentList>\n" +
	"      </action>\n" +
	"      <action>\n" +
	"         <name>GetSearchCapabilities</name>\n" +
	"         <argumentList>\n" +
	"            <argument>\n" +
	"               <name>SearchCaps</name>\n" +
	"               <direction>out</direction>\n" +
	"               <relatedStateVariable>SearchCapabilities</relatedStateVariable>\n" +
	"            </argument>\n" +
	"         </argumentList>\n" +
	"      </action>\n" +
	"      <action>\n" +
	"         <name>CreateObject</name>\n" +
	"         <argumentList>\n" +
	"            <argument>\n" +
	"               <name>ContainerID</name>\n" +
	"               <direction>in</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_ObjectID</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>Elements</name>\n" +
	"               <direction>in</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_Result</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>ObjectID</name>\n" +
	"               <direction>out</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_ObjectID</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>Result</name>\n" +
	"               <direction>out</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_Result</relatedStateVariable>\n" +
	"            </argument>\n" +
	"         </argumentList>\n" +
	"      </action>\n" +
	"      <action>\n" +
	"         <name>Search</name>\n" +
	"         <argumentList>\n" +
	"            <argument>\n" +
	"               <name>ContainerID</name>\n" +
	"               <direction>in</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_ObjectID</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>SearchCriteria</name>\n" +
	"               <direction>in</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_SearchCriteria</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>Filter</name>\n" +
	"               <direction>in</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_Filter</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>StartingIndex</name>\n" +
	"               <direction>in</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_Index</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>RequestedCount</name>\n" +
	"               <direction>in</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_Count</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>SortCriteria</name>\n" +
	"               <direction>in</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_SortCriteria</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>Result</name>\n" +
	"               <direction>out</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_Result</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>NumberReturned</name>\n" +
	"               <direction>out</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_Count</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>TotalMatches</name>\n" +
	"               <direction>out</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_Count</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>UpdateID</name>\n" +
	"               <direction>out</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_UpdateID</relatedStateVariable>\n" +
	"            </argument>\n" +
	"         </argumentList>\n" +
	"      </action>\n" +
	"      <action>\n" +
	"         <name>GetSortCapabilities</name>\n" +
	"         <argumentList>\n" +
	"            <argument>\n" +
	"               <name>SortCaps</name>\n" +
	"               <direction>out</direction>\n" +
	"               <relatedStateVariable>SortCapabilities</relatedStateVariable>\n" +
	"            </argument>\n" +
	"         </argumentList>\n" +
	"      </action>\n" +
	"      <action>\n" +
	"         <name>ImportResource</name>\n" +
	"         <argumentList>\n" +
	"            <argument>\n" +
	"               <name>SourceURI</name>\n" +
	"               <direction>in</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_URI</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>DestinationURI</name>\n" +
	"               <direction>in</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_URI</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>TransferID</name>\n" +
	"               <direction>out</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_TransferID</relatedStateVariable>\n" +
	"            </argument>\n" +
	"         </argumentList>\n" +
	"      </action>\n" +
	"      <action>\n" +
	"         <name>CreateReference</name>\n" +
	"         <argumentList>\n" +
	"            <argument>\n" +
	"               <name>ContainerID</name>\n" +
	"               <direction>in</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_ObjectID</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>ObjectID</name>\n" +
	"               <direction>in</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_ObjectID</relatedStateVariable>\n" +
	"            </argument>\n" +
	"            <argument>\n" +
	"               <name>NewID</name>\n" +
	"               <direction>out</direction>\n" +
	"               <relatedStateVariable>A_ARG_TYPE_ObjectID</relatedStateVariable>\n" +
	"            </argument>\n" +
	"         </argumentList>\n" +
	"      </action>\n" +
	"      <action>\n" +
	"         <name>GetSystemUpdateID</name>\n" +
	"         <argumentList>\n" +
	"            <argument>\n" +
	"              <name>Id</name>\n" +
	"               <direction>out</direction>\n" +
	"               <relatedStateVariable>SystemUpdateID</relatedStateVariable>\n" +
	"            </argument>\n" +
	"         </argumentList>\n" +
	"      </action>\n" +
	"   </actionList>\n" +
	"   <serviceStateTable>\n" +
	"      <stateVariable sendEvents=\"no\">\n" +
	"         <name>A_ARG_TYPE_SortCriteria</name>\n" +
	"         <dataType>string</dataType>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"no\">\n" +
	"         <name>A_ARG_TYPE_TransferLength</name>\n" +
	"         <dataType>string</dataType>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"yes\">\n" +
	"         <name>TransferIDs</name>\n" +
	"         <dataType>string</dataType>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"no\">\n" +
	"         <name>A_ARG_TYPE_UpdateID</name>\n" +
	"         <dataType>ui4</dataType>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"no\">\n" +
	"         <name>A_ARG_TYPE_SearchCriteria</name>\n" +
	"         <dataType>string</dataType>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"no\">\n" +
	"         <name>A_ARG_TYPE_Filter</name>\n" +
	"         <dataType>string</dataType>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"yes\">\n" +
	"         <name>ContainerUpdateIDs</name>\n" +
	"         <dataType>string</dataType>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"no\">\n" +
	"         <name>A_ARG_TYPE_Result</name>\n" +
	"         <dataType>string</dataType>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"no\">\n" +
	"         <name>A_ARG_TYPE_Index</name>\n" +
	"         <dataType>ui4</dataType>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"no\">\n" +
	"         <name>A_ARG_TYPE_TransferID</name>\n" +
	"         <dataType>ui4</dataType>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"no\">\n" +
	"         <name>A_ARG_TYPE_TagValueList</name>\n" +
	"         <dataType>string</dataType>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"no\">\n" +
	"         <name>A_ARG_TYPE_URI</name>\n" +
	"         <dataType>uri</dataType>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"no\">\n" +
	"         <name>A_ARG_TYPE_ObjectID</name>\n" +
	"         <dataType>string</dataType>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"no\">\n" +
	"         <name>SortCapabilities</name>\n" +
	"         <dataType>string</dataType>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"no\">\n" +
	"         <name>SearchCapabilities</name>\n" +
	"         <dataType>string</dataType>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"no\">\n" +
	"         <name>A_ARG_TYPE_Count</name>\n" +
	"         <dataType>ui4</dataType>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"no\">\n" +
	"         <name>A_ARG_TYPE_BrowseFlag</name>\n" +
	"         <dataType>string</dataType>\n" +
	"         <allowedValueList>\n" +
	"            <allowedValue>BrowseMetadata</allowedValue>\n" +
	"            <allowedValue>BrowseDirectChildren</allowedValue>\n" +
	"         </allowedValueList>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"yes\">\n" +
	"         <name>SystemUpdateID</name>\n" +
	"         <dataType>ui4</dataType>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"no\">\n" +
	"         <name>A_ARG_TYPE_TransferStatus</name>\n" +
	"         <dataType>string</dataType>\n" +
	"         <allowedValueList>\n" +
	"            <allowedValue>COMPLETED</allowedValue>\n" +
	"            <allowedValue>ERROR</allowedValue>\n" +
	"            <allowedValue>IN_PROGRESS</allowedValue>\n" +
	"            <allowedValue>STOPPED</allowedValue>\n" +
	"         </allowedValueList>\n" +
	"      </stateVariable>\n" +
	"      <stateVariable sendEvents=\"no\">\n" +
	"         <name>A_ARG_TYPE_TransferTotal</name>\n" +
	"         <dataType>string</dataType>\n" +
	"      </stateVariable>\n" +
	"   </serviceStateTable>\n" +
	"</scpd>";
	
	

	
	private String getNotifyDeviceNT()
	{
		if (isRootDevice() == false)
			return getUDN();			
		return UPNP_ROOTDEVICE;
	}
	



	
	////////////////////////////////////////////////
	// Constructor
	////////////////////////////////////////////////
	
	private final static String DESCRIPTION_FILE_NAME = "description/description.xml";
	
	public UPNPResponder(String descriptionFileName) throws InvalidDescriptionException
	{
		super(new File(descriptionFileName));
		initialize("127.0.0.1",8080);
	}
	
	

	public UPNPResponder() throws InvalidDescriptionException
	{
		
		this(DESCRIPTION, CONTENT_DIRECTORY_SCPD, CONNECTION_MANAGER_SCPD, MEDIA_RECEIVER_REGISTRAR_SCPD,"127.0.0.1",8080);
		
	}
	
	public UPNPResponder(String address,int port) throws InvalidDescriptionException
	{
		
		this(DESCRIPTION, CONTENT_DIRECTORY_SCPD, CONNECTION_MANAGER_SCPD, MEDIA_RECEIVER_REGISTRAR_SCPD,address,port);
		
	}
	
	public UPNPResponder(String address,int port,String Description) throws InvalidDescriptionException
	{
		
		this(Description, CONTENT_DIRECTORY_SCPD, CONNECTION_MANAGER_SCPD, MEDIA_RECEIVER_REGISTRAR_SCPD,address,port);
		
	}
	
	

	public UPNPResponder(String description, String contentDirectorySCPD, String connectionManagerSCPD, String mediaReceiverRegistrarSCPD, String address,int port) throws InvalidDescriptionException
	{
		super();
		
		//System.out.println(DESCRIPTION);
		
		loadDescription(description);
		
		Service servConDir = getService(CONTENT_DIRECTORY_SERVICE_TYPE);
		servConDir.loadSCPD(contentDirectorySCPD);
		
		Service servConMan = getService(CONNECTION_MANAGER_SERVICE_TYPE);
		servConMan.loadSCPD(connectionManagerSCPD);
		
		Service servmedRR = getService(MEDIA_RECEIVER_REGISTRAR_SERVICE_TYPE);
		servmedRR.loadSCPD(mediaReceiverRegistrarSCPD);
		
		initialize(address,port);
	}
	
	private void initialize(String address,int port)
	{
		// Netwroking initialization		
		UPnP.setEnable(UPnP.USE_ONLY_IPV4_ADDR);
		String firstIf = HostInterface.getHostAddress(0);
		
		//setInterfaceAddress(firstIf);

		setInterfaceAddress(address);

		//setHTTPPort(DEFAULT_HTTP_PORT);
		setHTTPPort(port);
				
	}
	

	
	protected void finalize()
	{
		stop();		
	}
	
	////////////////////////////////////////////////
	// Memeber
	////////////////////////////////////////////////
	

	
	
	
	






	
	////////////////////////////////////////////////
	// HostAddress
	////////////////////////////////////////////////

	public void setInterfaceAddress(String ifaddr)
	{
		System.out.println(ifaddr);
		HostInterface.setInterface(ifaddr);
	}			
	
	public String getInterfaceAddress()
	{
		return HostInterface.getInterface();
	}			

	////////////////////////////////////////////////
	// HttpRequestListner (Overridded)
	////////////////////////////////////////////////
	
	public void httpRequestRecieved(HTTPRequest httpReq)
	{
		String uri = httpReq.getURI();
		Debug.message("uri = " + uri);
		System.out.println("uri = " + uri);
	
		 
		super.httpRequestRecieved(httpReq);
	}
	
	////////////////////////////////////////////////
	// start/stop (Overided)
	////////////////////////////////////////////////
	
	public void deviceSearchResponse(SSDPPacket ssdpPacket)
	{		
		//System.out.println("using mediaservers search response");
		String ssdpST = ssdpPacket.getST();

		if (ssdpST == null)
			return;

		boolean isRootDevice = isRootDevice();
		
		String devUSN = getUDN();		
			
		if (ST.isAllDevice(ssdpST) == true) {			
			String devNT = getNotifyDeviceNT();			
			int repeatCnt = (isRootDevice == true) ? 3 : 2;
			for (int n=0; n<repeatCnt; n++)
				postSearchResponse(ssdpPacket, devNT, devUSN);
		}
		else if (ST.isRootDevice(ssdpST) == true) {
			if (isRootDevice == true)
				postSearchResponse(ssdpPacket, ST.ROOT_DEVICE, devUSN);
		}
		else if (ST.isUUIDDevice(ssdpST) == true) {
			String devUDN = getUDN();
			if (ssdpST.equals(devUDN) == true)
				postSearchResponse(ssdpPacket, devUDN, devUSN);
		}
		else if (ST.isURNDevice(ssdpST) == true) {
			String devType= getDeviceType();
			if (ssdpST.equals(devType) == true) {
				// Thanks for Mikael Hakman (04/25/05)
				devUSN = getUDN() + "::" + devType;
				postSearchResponse(ssdpPacket, devType, devUSN);
			}
		}
		
		ServiceList serviceList = getServiceList();
		int serviceCnt = serviceList.size();
		for (int n=0; n<serviceCnt; n++) {
			Service service = serviceList.getService(n);
			service.serviceSearchResponse(ssdpPacket);
		}
		
	}
	
	public boolean start()
	{
		super.start();
		return true;
	}
	
	private boolean stop(boolean doByeBye)
	{
		super.stop();

		return true;
	}
	
	////////////////////////////////////////////////
	// update
	////////////////////////////////////////////////

	public void update()
	{
	}			

}

