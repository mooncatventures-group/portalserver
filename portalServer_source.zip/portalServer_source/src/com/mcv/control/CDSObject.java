/*
 *  Copyright (C) 2004 Cidero, Inc.
 *
 *  Permission is hereby granted to any person obtaining a copy of 
 *  this software to use, copy, modify, merge, publish, and distribute
 *  the software for any non-commercial purpose, subject to the
 *  following conditions:
 *  
 *  The above copyright notice and this permission notice shall be included
 *  in all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS 
 *  OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
 *  THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY IN CONNECTION WITH THE SOFTWARE.
 * 
 *  File: $RCSfile: CDSObject.java,v $
 *
 */

package com.mcv.control;

import java.util.Vector;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

import javax.swing.ImageIcon;

import net.sf.json.JSONObject;

import org.w3c.dom.DOMException;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import org.cybergarage.xml.XML;

public abstract class CDSObject implements Cloneable {

	private static Logger logger = Logger.getLogger("CDSObject");

	String id; // Unique object id (Req.)
	String parentId; // Id of object's parent. Root parent = -1 (Req.)
	String childCount;
	String containerType;
	ConcurrentHashMap map = new ConcurrentHashMap();
	private JSONObject jsonFormatedObj;

	/**
	 * Simple constructor to create empty object
	 */
	public CDSObject(Node node, String container , String rootParent) {

		this.setContainerType(container);

		NamedNodeMap attributes = node.getAttributes();
		for (int n = 0; n < attributes.getLength(); n++) {
			System.out.println("node attr ");
			Node current = attributes.item(n);
			System.out.println(" " + current.getNodeName() + "=\""
					+ current.getNodeValue() + "\"");

			String name = current.getNodeName();
			String value = current.getNodeValue();

			if (name.contains("id"))
				this.setId(value);
			if (name.contains("parentID"))
				this.setParentId(rootParent+"-"+value);
			if (name.contains("childCount"))
				this.setChildCount(value);
		}

		if (this.id != null)
			map.put(new String("\"id\""), this.id);
		if (this.parentId != null)
			map.put("\"parentID\"", this.parentId);
		// if (this.containerType !=null) map.put("type", this.containerType);
		if (this.containerType != null) {
			if (this.containerType.contains("object.container")) {
				map.put("\"type\"", "folder");
			} else {
				map.put("\"type\"", "item");

			}
		}

		if (this.childCount != null)
			map.put("\"childCount\"", this.childCount);

		NodeList children = node.getChildNodes();

		for (int n = 0; n < children.getLength(); n++)

		{

			String nodeName = children.item(n).getNodeName();
			String nodeSingleValue = getSingleTextNodeValue(children.item(n));
			System.out.println(nodeName + "="
					+ getSingleTextNodeValue(children.item(n)));
			
			if (nodeName.contains("#text")) continue;
			
			if (this.containerType.contains("object.container")) {
				if (nodeName.contains("res"))  continue;
			
			}
			
			if (nodeName != null && nodeSingleValue != null) {
				nodeName = "\""+nodeName+"\"";
				map.put(nodeName.replace(":", ""), nodeSingleValue);
			}

		}

	}

	public static String getSingleTextNodeValue(Node node) {
		NodeList children = node.getChildNodes();

		// System.out.println( "nChildren = " + children.getLength() );

		for (int n = 0; n < children.getLength(); n++) {
			String nodeName = children.item(n).getNodeName();

			// System.out.println( "Inner Node is: " + nodeName );
		}

		if (children.getLength() != 1) // blank text item
		{
			// System.out.println("Warning: missing or non-singular text node");
			return "";
		}

		if (children.item(0).getNodeType() != Node.TEXT_NODE) {
			logger.warning("unexpected node type");
			return null;
		}

		return (String) children.item(0).getNodeValue();

	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the parentId
	 */
	public String getParentId() {
		return parentId;
	}

	/**
	 * @param parentId
	 *            the parentId to set
	 */
	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

	/**
	 * @return the childCount
	 */
	public String getChildCount() {
		return childCount;
	}

	/**
	 * @param childCount
	 *            the childCount to set
	 */
	public void setChildCount(String childCount) {
		this.childCount = childCount;
	}

	/**
	 * @return the title
	 */

	/**
	 * @return the containerType
	 */
	public String getContainerType() {
		return containerType;
	}

	/**
	 * @param containerType
	 *            the containerType to set
	 */
	public void setContainerType(String containerType) {
		this.containerType = containerType;
	}

	/**
	 * @return the resourceList
	 */
	/**
	 * @return the map
	 */
	public ConcurrentHashMap getMap() {
		return map;
	}

	/**
	 * @param map
	 *            the map to set
	 */
	public void setMap(ConcurrentHashMap map) {
		this.map = map;
	}

	/**
	 * @return the jsonFormatedObj
	 */
	public JSONObject getJsonFormatedObj() {
		return jsonFormatedObj;
	}

	/**
	 * @param jsonFormatedObj
	 *            the jsonFormatedObj to set
	 */
	public void setJsonFormatedObj(JSONObject jsonFormatedObj) {
		this.jsonFormatedObj = jsonFormatedObj;
	}

}
