/**
 * 
 */
package com.mcv.control;

import java.util.Iterator;

import org.apache.commons.jxpath.JXPathContext;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;

import com.bastet.control.MpBrowse;

/**
 * @author HP_Owner
 * 
 */
public class DlnaQueryResult {
	private Document dlnaResponse;
	static Logger log = Logger.getLogger("DlnaQueryResult");
	private static String INITIAL_MENU_REQUEST = "0";
	private static String INITIAL_XPATH = "/*/container/@parentID | /*/container/@id  | /*/container/upnp:class | /*/container/dc:title";

	/**
	 * 
	 */
	public DlnaQueryResult(Document doc, String objectId) {

		if (objectId.equals(INITIAL_MENU_REQUEST))
			doDomToMedia(doc, INITIAL_XPATH);

	}

	private Object doDomToMedia(Document doc, String xpathFromQuery) {

		/* set up an xpath context */
		JXPathContext context = JXPathContext.newContext(doc);
		/* iterate through the return results */

		Iterator it = context.iterate(xpathFromQuery);
		return it;

	}

	public Document getDlnaResponse() {
		return dlnaResponse;
	}

	public void setDlnaResponse(Document dlnaResponse) {
		this.dlnaResponse = dlnaResponse;
	}

	public static String getINITIAL_XPATH() {
		return INITIAL_XPATH;
	}

	public static void setINITIAL_XPATH(String initial_xpath) {
		INITIAL_XPATH = initial_xpath;
	}

}
