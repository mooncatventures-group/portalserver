package com.mcv.control;

import org.cybergarage.upnp.*;
import org.cybergarage.upnp.media.player.MediaPlayer;
import org.cybergarage.upnp.media.player.action.BrowseAction;
import org.cybergarage.upnp.media.server.ContentDirectory;
import org.cybergarage.upnp.ssdp.*;
import org.cybergarage.upnp.device.*;
import org.cybergarage.upnp.event.*;
import org.cybergarage.xml.Node;
import org.cybergarage.xml.Parser;
import org.cybergarage.xml.ParserException;
import org.w3c.dom.Document;
import com.apple.dnssd.DNSSD;
import com.apple.dnssd.DNSSDException;
import com.apple.dnssd.DNSSDRegistration;
import com.apple.dnssd.DNSSDService;
import com.apple.dnssd.RegisterListener;
import com.apple.dnssd.TXTRecord;
import com.mcv.upnp.CdsObjects;

import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;

import java.io.IOException;
import java.net.ServerSocket;
import java.util.concurrent.ConcurrentHashMap;

public class SSDPDiscover extends MediaPlayer implements NotifyListener,
		EventListener, SearchResponseListener, DeviceChangeListener,
		RegisterListener {

	public static ConcurrentHashMap upnpDeviceMap = new ConcurrentHashMap();
	public static final String ServiceType = "_html._tcp";
	static Logger log = Logger.getLogger("SSDPDiscover");

	private final int port;
	private final String host;

	/**
	 * @param _host
	 * @param _port
	 */
	public SSDPDiscover(String _host, int _port) {
		addNotifyListener(this);
		addSearchResponseListener(this);
		addEventListener(this);
		addDeviceChangeListener(this);

		final String pattern = "%d{ISO8601}::%p: %C{1}:  %m %n";
		final ConsoleAppender appender = new ConsoleAppender(new PatternLayout(
				pattern));
		SSDPDiscover.log.addAppender(appender);

		this.port = _port;
		this.host = _host;
	}

	// //////////////////////////////////////////////
	// Listener
	// //////////////////////////////////////////////

	/*
	 * (non-Javadoc)
	 * 
	 * @seeorg.cybergarage.upnp.device.NotifyListener#deviceNotifyReceived(org.
	 * cybergarage.upnp.ssdp.SSDPPacket)
	 */
	public void deviceNotifyReceived(SSDPPacket packet) {
		System.out.println(packet.toString());

		if (packet.isDiscover() == true) {
			final String st = packet.getST();
			printConsole("ssdp:discover : ST = " + st);
		} else if (packet.isAlive() == true) {
			final String usn = packet.getUSN();
			final String nt = packet.getNT();
			final String url = packet.getLocation();
			printConsole("ssdp:alive : uuid = " + usn + ", NT = " + nt
					+ ", location = " + url);
		} else if (packet.isByeBye() == true) {
			final String usn = packet.getUSN();
			final String nt = packet.getNT();
			printConsole("ssdp:byebye : uuid = " + usn + ", NT = " + nt);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @seeorg.cybergarage.upnp.device.SearchResponseListener#
	 * deviceSearchResponseReceived(org.cybergarage.upnp.ssdp.SSDPPacket)
	 */
	public void deviceSearchResponseReceived(SSDPPacket packet) {
		final String uuid = packet.getUSN();
		final String st = packet.getST();
		final String url = packet.getLocation();
		printConsole("device search res : uuid = " + uuid + ", ST = " + st
				+ ", location = " + url);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.cybergarage.upnp.event.EventListener#eventNotifyReceived(java.lang
	 * .String, long, java.lang.String, java.lang.String)
	 */
	public void eventNotifyReceived(String uuid, long seq, String name,
			String value) {
		printConsole("event notify : uuid = " + uuid + ", seq = " + seq
				+ ", name = " + name + ", value =" + value);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.cybergarage.upnp.device.DeviceChangeListener#deviceAdded(org.cybergarage
	 * .upnp.Device)
	 */
	public void deviceAdded(Device dev) {

		printConsole("new device added " + dev.getFriendlyName());

		if (dev.getDeviceType().equals(
				"urn:schemas-upnp-org:device:MediaServer:1")) {

			// printConsole("found 1 mediaserver " + dev.getDeviceType());
			// }
			printConsole("found 1 mediadevice  " + dev.getDeviceType());
			if (!SSDPDiscover.upnpDeviceMap.containsKey(dev.getFriendlyName())) {
				final TXTRecord txtRecord = new TXTRecord();
				txtRecord.set("txtvers", "1");
				// txtRecord.set("ServiceType", "UNP,Mediaserver "
				// );
				// txtRecord.set("FriendlyName", dev.getFriendlyName());
				txtRecord.set("UPU", "fdn=" + dev.getFriendlyName() + "&UDN="
						+ dev.getUDN());
				//if (dev.getInterfaceAddress() != null) {
				txtRecord.set("domain", host+":"+port);
				//}
				SSDPDiscover.log.info("Registration Starting");
				SSDPDiscover.log.info("Requested Name: "
						+ dev.getFriendlyName());
				SSDPDiscover.log.info("Port: " + port);
				

				try {
					ServerSocket s = new ServerSocket(0);
					DNSSDRegistration dnssdRegistrion = 
						this.TestRegister(dev.getFriendlyName(), s.getLocalPort(),port+"",dev.getUDN());
					
					
					/*final DNSSDRegistration dnssdRegistrion = DNSSD.register(0,
							DNSSD.ALL_INTERFACES, dev.getFriendlyName(),
							ServiceType, "local.", // Name, type, and domain
							host, s.getLocalPort(), // Target host and port
							txtRecord, this); // TXT record and listener object
							*/
					SSDPDiscover.upnpDeviceMap.put(dev.getFriendlyName(),
							dnssdRegistrion);
				} catch (final DNSSDException e) {
					// TODO Auto-generated catch block
				//	e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					//e.printStackTrace();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					//e.printStackTrace();
				}
			}

			// urn:philips-com:device:PhilipsMediaServer
		} else

		{
			// Check embedded devices
			final DeviceList devList = dev.getDeviceList();
			final int devCnt = devList.size();

			for (int n = 0; n < devCnt; n++) {
				final Device embeddedDev = devList.getDevice(n);

				System.out.println("  Checking embedded device " + n);
				System.out.println(" deviceType: "
						+ embeddedDev.getDeviceType());
				System.out.println(" friendlyName: "
						+ embeddedDev.getFriendlyName());

				// Set location field in embedded device for benefit of URLBase
				// logic
				embeddedDev.setLocation(dev.getLocation());

				if (embeddedDev.getDeviceType().indexOf("MediaServer") >= 0) {
					printConsole("found embedded server  "
							+ dev.getDeviceType());
					if (!SSDPDiscover.upnpDeviceMap.containsKey(dev
							.getFriendlyName())) {
						try {
							ServerSocket s = new ServerSocket(0);
							this.TestRegister(dev.getFriendlyName(), s.getLocalPort(),port+"" ,dev.getUDN());
						} catch (DNSSDException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							
						} catch (IOException e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
}
					}

				}

			}

		}

	

	/**
	 * @param msg
	 */
	public void printConsole(String msg) {
		System.out.println(msg);
	}

	public void deviceRemoved(Device dev) {

		printConsole("A device removed " + dev.getFriendlyName());
		if (SSDPDiscover.upnpDeviceMap.contains(dev.getFriendlyName())) {

			;
		}
		{
			final DNSSDRegistration r = (DNSSDRegistration) SSDPDiscover.upnpDeviceMap
					.get(dev.getFriendlyName());
			r.stop();
			SSDPDiscover.upnpDeviceMap.remove(dev.getFriendlyName());

		}

	}

	/**
	 * @return
	 */
	public static ConcurrentHashMap getUpnpDeviceMap() {
		return upnpDeviceMap;
	}

	/**
	 * @param upnpDeviceMap
	 */
	public static void setUpnpDeviceMap(ConcurrentHashMap upnpDeviceMap) {
		SSDPDiscover.upnpDeviceMap = upnpDeviceMap;
	}

	public static void main(String args[]) {

		final SSDPDiscover mpcontrol = new SSDPDiscover("172.16.1.33", 80);

		mpcontrol.start();

	}

	// Display error message on failure
	public void operationFailed(DNSSDService service, int errorCode) {
		System.out.println("Registration failed " + errorCode);
	}

	// Display registered name on success
	public void serviceRegistered(DNSSDRegistration registration, int flags,
			String serviceName, String regType, String domain) {
		System.out.println("Registered Name  : " + serviceName);
		System.out.println("           Type  : " + regType);
		System.out.println("           Domain: " + domain);
	}

	/**
	 * @return
	 */
	public DeviceList getAllDevices() {
		search("upnp:rootdevice");
		DeviceList rootDevList = getDeviceList();
		int nRootDevs = rootDevList.size();
		for (int n = 0; n < nRootDevs; n++) {
			Device dev = rootDevList.getDevice(n);
			String devName = dev.getFriendlyName();
			System.out.println("[" + n + "] = " + devName);
		}

		return rootDevList;

	}

	public Device findDevice(String name) {
		search("upnp:rootdevice");
		return getDevice(name);

	}

	/**
	 * @param dev
	 * @param objectID
	 * @param browseFlag
	 * @param filter
	 * @param startIndex
	 * @param requestedCount
	 * @param sortCaiteria
	 * @return
	 */
	private Document browseContent(Device dev, String objectID,
			String browseFlag, String filter, int startIndex,
			int requestedCount, String sortCaiteria) {
		// System.out.println("browse " + objectID + ", " + browseFlag + ", " +
		// startIndex + ", " + requestedCount + " " + dev);

		if (dev == null)
			return null;

		Service conDir = dev
				.getService("urn:schemas-upnp-org:service:ContentDirectory:1");
		ServiceList servicelist = dev.getServiceList();
		if (conDir == null)
			return null;
		Action action = conDir.getAction("Browse");
		// if (action == null)
		// return null;
		BrowseAction browseAction = new BrowseAction(action);
		browseAction.setObjectID(objectID);
		browseAction.setBrowseFlag(browseFlag);
		browseAction.setStartingIndex(startIndex);
		browseAction.setRequestedCount(requestedCount);
		browseAction.setFilter(filter);
		browseAction.setSortCriteria(sortCaiteria);
		if (browseAction.postControlAction() == false)
			return null;

		Argument resultArg = browseAction.getArgument(BrowseAction.RESULT);

		if (resultArg == null)
			return null;

		String resultStr = resultArg.getValue();

		if (resultStr == null)
			return null;
		try {
			CdsObjects DomDoc = new CdsObjects(resultStr);
			return DomDoc.getDomDoc();
		} catch (Exception e) {
		}
		;
		return null;
	}

	// //////////////////////////////////////////////
	// browse*
	// //////////////////////////////////////////////

	public Document browseMeta(Device dev, String objectID, String filter,
			int startIndex, int requestedCount, String sortCaiteria) {
		return browseContent(dev, objectID, BrowseAction.BROWSE_METADATA,
				filter, startIndex, requestedCount, sortCaiteria);
	}

	public Document browseChildren(Device dev, String objectID, String filter,
			int startIndex, int requestedCount, String sortCaiteria) {
		return browseContent(dev, objectID,
				BrowseAction.BROWSE_DIRECT_CHILDREN, filter, startIndex,
				requestedCount, sortCaiteria);
	}

	/**
	 * @param dev
	 * @param objectID
	 * @return
	 */
	public Document browseServer(Device dev, String objectID) {

		Document doc = browseMeta(dev, "0", "*", 0, 0, "");

		return browseChildren(dev, objectID, "*", 0, 0, "");

	}
	
	public DNSSDRegistration  TestRegister(String name, int port, String interfacePort, String udn)
	throws DNSSDException, InterruptedException
	{
	System.out.println("Registration Starting");
	System.out.println("Requested Name: " + name);
	System.out.println("          Port: " + port);
	//DNSSDRegistration r = DNSSD.register("Moët & Chandon", "_example._tcp", 9099, this);
	// New code to register with TXT record begins here
	TXTRecord txtRecord = new TXTRecord();
	txtRecord.set("txtvers", "1");
	txtRecord.set("path",udn );
	txtRecord.set("port", interfacePort);
	DNSSDRegistration r = DNSSD.register(DNSSD.UNIQUE, DNSSD.ALL_INTERFACES,
		name, "_html._tcp", null,	// Name, type, and domain
		null, port,						// Target host and port
		txtRecord, this);				// TXT record and listener object
	  return r;
	}
	
}
