/**
 * 
 */
package com.mcv.control;

import java.io.ByteArrayOutputStream;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.util.WebUtils;

/**
 * @author HP_Owner
 *
 */
public class MediaResponseObject {
	private JSONArray mediaArray = new JSONArray();

	
	public MediaResponseObject() {
	
	}
	
	public void add(JSONObject json) {
		mediaArray.add(json);
		
	}

	/**
	 * @return the mediaArray
	 */
	public String getMediaArray() {
		return "{\"results\":"+ 
	 	 WebUtils.toString(JSONArray.fromObject(this.mediaArray))+"}";
	}
	
	
	/**
	 * @param mediaArray the mediaArray to set
	 */
	public void setMediaArray(JSONArray mediaArray) {
		this.mediaArray = mediaArray;
	}
	
	
		
	

}
