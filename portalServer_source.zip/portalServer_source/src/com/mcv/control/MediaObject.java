/**
 * 
 */
package com.mcv.control;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JSONSerializer;
import net.sf.json.util.WebUtils;

import org.w3c.dom.Node;

/**
 * @author mooncatventures
 * 
 */
public class MediaObject extends CDSObject {

	/**
	 * 
	 */
	public MediaObject(Node node, String container, String rootParent) {
		super(node, container, rootParent);
		this.setJsonFormatedObj(JSONObject.fromObject(this.getMap()));

	}

}
