/**
 * one line to give the program's name and an idea of what it does.
 Copyright (C) 2006  Thomas Walker

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 2
 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package com.mcv.servlet;

import java.net.ServerSocket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.ezmorph.bean.MorphDynaBean;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.xml.XMLSerializer;

import org.apache.commons.beanutils.DynaProperty;
import org.apache.log4j.Logger;
import org.apache.xpath.XPathContext;
import org.cybergarage.upnp.Device;
import org.cybergarage.upnp.DeviceList;
import org.cybergarage.upnp.media.server.object.ContentNode;
import org.cybergarage.xml.Node;
import org.mortbay.log.Log;
import org.w3c.dom.Document;
import com.mcv.control.SSDPDiscover;
import com.mcv.upnp.CdsObjects;
import com.mcv.upnp.MpDomUtil;
import org.apache.commons.jxpath.JXPathContext; 
import org.w3c.dom.Document; 
import org.xml.sax.InputSource; 

import java.io.BufferedOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.StringReader; 
import java.io.Writer;
import java.util.Iterator;

/**
 * Servlet covering the whole media server
 * 
 * @author tom
 * 
 */
public class MediaServer extends HttpServlet {
	// TODO maybe move servlet functionality into a smaller class to simplify
	// things
	static Logger logger = Logger.getLogger("MediaServer");
	SSDPDiscover upnpResponder;
	private Document document;

	protected ResourceBundle resbundle;
	int port = 0;
	WebServer webserver;

	private String externalAddress = "";

	public MediaServer(int port) {

		super();
		try {

			setup("", port);
		} catch (final Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		MediaServer.logger.info("Starting media server");

	}

	public MediaServer(String externalAddress) {
		super();
		this.externalAddress = externalAddress;
		this.port = port;
		MediaServer.logger.info("Starting media server servlet with address:"
				+ this.externalAddress);
		setup(externalAddress, port);

	}

	public MediaServer(String externalAddress, int port) {
		super();
		this.externalAddress = externalAddress;
		this.port = port;
		MediaServer.logger.info("Starting media server with address:"
				+ this.externalAddress + " and port:" + port);
		setup(externalAddress, port);
	}

	private void setup(String externalAddress, int port) {
		this.externalAddress = externalAddress;
		this.port = port;
		try {
			String host;
			if (externalAddress == "") {
				host = null;
			} else {
				host = externalAddress;
			}

			upnpResponder = new SSDPDiscover(host, port);
			upnpResponder.start();
			if (!upnpResponder.start()) {
				MediaServer.logger.fatal("Couldnt start listener");
			} else {
				setUpWebServer();
			}
		} catch (final Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void setUpWebServer() {
		webserver = new WebServer(this);
		webserver.addConnector(this.externalAddress, this.port);
		Log.info("using externalAddress " + externalAddress + " port "
				+ this.port);
		// webserver.addConnector("127.0.0.1", 8082);
		webserver.start();
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) {
		MediaServer.logger.debug("Do Post:" + req.getPathInfo());
		/*
		 * try { if (req.getPathInfo().contains(config.contentDirectoryPath)) {
		 * MediaServer.logger.debug("Sending to content dir"); //
		 * contentDirectory.doPost(req,resp); } else if
		 * (req.getPathInfo().contains(config.mediaRecRegPath)) { //
		 * mediaRecReg.doPost(req,resp); } else if
		 * (req.getPathInfo().contains("configure")) {
		 * MediaServer.logger.info("Doing configure"); //
		 * configurator.doPost(req,resp); } } catch (final Exception e) {
		 * MediaServer.logger.error(e.toString()); }
		 */
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) {

		try {
			MediaServer.logger.debug(req.getRemoteAddr() + ":"
					+ req.getPathInfo());
			// if(req.getPathInfo().contains(config.contentDirectoryPath)){
			MediaServer.logger.debug("Got Content Dir");
			
			OutputStream raw = new BufferedOutputStream(
                    resp.getOutputStream()
                    );
            Writer out = new OutputStreamWriter(raw);
			
			resp.setContentType("text/html");
			resp.setStatus(HttpServletResponse.SC_OK);
			//out.write("<h1>Hello from MediaBridge</h1>");
			Device devi = upnpResponder.findDevice(req.getParameter("UDN"));
			if (devi == null) {
				devi = upnpResponder.findDevice(req.getParameter("fdn"));
			}

			Node node = upnpResponder.browseMetaData(devi, "0", "*", 0, 0, "");
			
			
			Node content = upnpResponder.browseDirectChildren(devi, req
					.getParameter("id"), "*", 0, 0, "");
			
         /* original parent */
			String parentRoot = req.getParameter("pid");
		//	Node content = upnpResponder.searchChildren(devi, req
			//		.getParameter("id"), "*", 0, 0, "");
			
			DomUtilities domUtil = new DomUtilities();
			//domPrint.parse(content.toString(), "", "/*/*",resp.getWriter());
			 CdsObjects DomDoc = new CdsObjects(content.toXMLString());
			// domPrint.PrintDom(DomDoc.getDomDoc(), resp.getWriter());
			 domUtil.domToResponse(DomDoc.getDomDoc(), parentRoot);
			 out.write(domUtil.getMediaResponseObject().getMediaArray());
			 out.flush();
			
		

		} catch (final Exception e) {
			e.printStackTrace();
			MediaServer.logger.error(e.toString());
		}
	}
	
	public String  Json(String content) {
		XMLSerializer xmlSerializer = new XMLSerializer();

		JSONObject json = (JSONObject) xmlSerializer.read( content);  
		return json.toString();
	}

	

}
