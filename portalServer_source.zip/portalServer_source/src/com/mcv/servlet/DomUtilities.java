package com.mcv.servlet;

 import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.xml.namespace.QName;

import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.xpath.XPathFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import net.sf.json.JSONObject;

import org.apache.xpath.XPathAPI;
import org.w3c.dom.NodeList;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.traversal.NodeIterator;

import com.mcv.control.CDSObject;
import com.mcv.control.MediaObject;
import com.mcv.control.MediaResponseObject;


public class DomUtilities {
	private StringBuffer sb = new StringBuffer();
	private MediaResponseObject mediaResponseObject = new MediaResponseObject();
	   
    private void display_result(Source result) {
    
    }  
    

    public void parse(String xml, String msg, String pattern, PrintWriter writer) {
        StreamSource source =
            new StreamSource(new ByteArrayInputStream(xml.getBytes()));
        DOMResult dom_result = new DOMResult();
        System.out.println(msg);
        try {
            Transformer trans = TransformerFactory.newInstance().newTransformer();
            trans.transform(source, dom_result);
            XPathFactory xpf = XPathFactory.newInstance();
            XPath xp = xpf.newXPath();
            NodeList list = (NodeList)
                xp.evaluate(pattern, dom_result.getNode(), XPathConstants.NODESET);
            int len = list.getLength();
            for (int i = 0; i < len; i++) {
                Node node = list.item(i);
                if (node != null) 
                  writer.println(node.getNodeName()+"="+node.getFirstChild().getNodeValue());
            }
        }
        catch(TransformerConfigurationException e) { System.err.println(e); }
        catch(TransformerException e) { System.err.println(e); }
        catch(XPathExpressionException e) { System.err.println(e); }
    }
    
 public void PrintDom( Document doc , PrintWriter writer) {
        
        
        try {
            // Set up an identity transformer to use as serializer.
            Transformer serializer = TransformerFactory.newInstance().newTransformer();
            serializer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            String xpath = "./*";
            // Use the simple XPath API to select a nodeIterator.
          //  writer.println("Querying DOM using "+xpath);
            NodeIterator nl = XPathAPI.selectNodeIterator(doc, xpath);
            
            // Serialize the found nodes to System.out.
         
            System.out.println("<output>");
            String xmls=null;
            Node n;
            while ((n = nl.nextNode())!= null) {
                if (isTextNode(n)) {
                    // DOM may have more than one node corresponding to a
                    // single XPath text node.  Coalesce all contiguous text nodes
                    // at this level
                    StringBuffer sb = new StringBuffer(n.getNodeValue());
                    for (
                            Node nn = n.getNextSibling();
                    isTextNode(nn);
                    nn = nn.getNextSibling()
                    ) {
                    /*    sb.append(nn.getNodeValue());*/
                    }
                    writer.println(sb);
                } else {
                   
                 /*   StringWriter buffer = new StringWriter();
                    StreamResult result = new StreamResult(buffer);
                    serializer.transform(new DOMSource(n),  result);
                    String encoded = buffer.getBuffer().toString();
                    writer.println(encoded);*/
                    
                }
                writer.println();
            }
            writer.println("</output>");
            
        }   catch (Exception e) {};
    }
    
    /** Decide if the node is text, and so must be handled specially */
    static boolean isTextNode(Node n) {
        if (n == null)
            return false;
        short nodeType = n.getNodeType();
        return nodeType == Node.CDATA_SECTION_NODE || nodeType == Node.TEXT_NODE;
    }
    
    public String printNode( Node node, String indent) 
    {

    	 
      // Determine type of node
      switch( node.getNodeType() )
      {
        case Node.DOCUMENT_NODE:
          sb.append("<xml version = \"1.0\">\n");
          Document doc = (Document)node;
          printNode( doc.getDocumentElement(), "");
          break;

        case Node.ELEMENT_NODE:
          String name = node.getNodeName();
         // resp.getWriter().print( indent + "<" + name );
          sb.append(name);

          NamedNodeMap attributes = node.getAttributes();
          for( int n = 0 ; n < attributes.getLength() ; n++ )
          {
            Node current = attributes.item(n);
            sb.append( " " + current.getNodeName() +
                              "=\"" + current.getNodeValue() +
                              "\"" );
          
          }
         
          
          NodeList children = node.getChildNodes();

          // If simple node, don't bother with newline between tags
          if( (children != null) && (children.getLength() > 0) &&
              (attributes.getLength() > 0 ) )
          {
        	  sb.append( ">" );
          }
          else
          {
        	  sb.append( ">" );
          }
          

          // Recurse on children

          if( children != null )
          {
            for( int n = 0 ; n < children.getLength() ; n++ )
            {
              printNode( children.item(n), indent + "  " );
            }
          }
          
          if( (children != null) && (children.getLength() > 0) &&
              (attributes.getLength() > 0 ) )
          {
        	  sb.append( indent + "</" + name + ">" );
          }
          else
          {
        	  sb.append( "</" + name + ">" );
          }

          break;
          
        case Node.TEXT_NODE:
        case Node.CDATA_SECTION_NODE:

        	sb.append( node.getNodeValue() );
          break;

        case Node.PROCESSING_INSTRUCTION_NODE:
          
          break;

        case Node.ENTITY_REFERENCE_NODE:
          
          break;

        case Node.DOCUMENT_TYPE_NODE:
          
          break;


      }
      return sb.toString();
      
    }
    
    public void domToResponse( Node node , String parentRoot)
    {

      switch( node.getNodeType() )
      {

        case Node.DOCUMENT_NODE:
          System.out.println("<xml version = \"1.0\">\n");
          Document doc = (Document)node;
          domToResponse( doc.getDocumentElement() , parentRoot);
          break;

        case Node.ELEMENT_NODE:

          //
          // This is the DIDL-Lite node - Process all children containers and/or
          // items (non recursively)
          //
          System.out.println("Element node: " + node.getNodeName() );
          prepareCDS( node.getChildNodes() , parentRoot);
          break;


      }
    }
    
    public void prepareCDS( NodeList nodeList , String parentRoot )
    {
      
      System.out.println("N child nodes: " + nodeList.getLength() );

      for( int n = 0 ; n < nodeList.getLength() ; n++ )
      {
        Node node = nodeList.item(n);
        
        System.out.println("child node: " + node.getNodeName() +
                           "value: [" + node.getNodeValue() + "]" );


        // Skip over non-element nodes
        if( node.getNodeType() != Node.ELEMENT_NODE )
        {
          System.out.println("Not an element - skipping\n");
          continue;
        }
        
        
        
        
        Element element = (Element)node;
        
        NodeList classElementList = element.getElementsByTagName( "upnp:class" );

        if( classElementList.getLength() != 1 )
        {
          System.out.println("Error - element has no upnp class tag\n");
          continue;
        }
        
        System.out.println("Found matching upnp:class element\n");

        // Should be single text sub-node containing class name

        NodeList textNodeList = classElementList.item(0).getChildNodes();
        
        if( textNodeList.getLength() != 1 )
        {
          System.out.println("Error - upnp class element childNodes != 1\n");
          continue;
        }

        try
        {
          String upnpClass = textNodeList.item(0).getNodeValue();
          
    

          // Instantiate object of the appropriate type and initialize it
          // with all the data in the DOM version of the UPNP container/item 

          System.out.println("upnpClass is: " + upnpClass );

          CDSObject obj = CreateCDSObject( upnpClass,node , parentRoot);
          System.out.println("new json "+obj.getJsonFormatedObj().toString());
          JSONObject json = obj.getJsonFormatedObj();
          mediaResponseObject.add(json);

        }
        catch( DOMException e )
        {
          System.out.println("UPNP class not found" + e.getMessage() );
        }

      }

    }
    
   public CDSObject CreateCDSObject( String upnpClass,Node node, String parentRoot )
    {
      System.out.println("UPNP class '" + upnpClass + "'  back to XML" );

      

      if( upnpClass.equals( "object.item.videoItem.movie" ) )
      {
        //
        // Call form of constructor that takes a DOM node
        // DOM node gets passed down constructor chain all the way to
        // the base class.
        //
       // CDSOject movie = new CDSObject( node );
    	  MediaObject mObj = new MediaObject(node, upnpClass, parentRoot);
        System.out.println( "name="+node.getNodeName()+" value="+node.getTextContent());
        return mObj;

      }
      else if( upnpClass.equals( "object.item.videoItem" ) )
      {
        //CDSVideoItem videoItem = new CDSVideoItem( node );
        //System.out.println( videoItem.toXML( filter ) );
      //  System.out.println( node.getNodeName()+" "+node.getTextContent());
    	  MediaObject mObj = new MediaObject(node, upnpClass, parentRoot);
        System.out.println( "name="+node.getNodeName()+" value="+node.getTextContent());
        return mObj;
      }
      else if( upnpClass.equals( "object.item.imageItem.photo" ) )
      {
      //  CDSPhoto photo = new CDSPhoto( node );
    	  //System.out.println( node.getNodeName()+" "+node.getTextContent());
    	  MediaObject mObj = new MediaObject(node, upnpClass,parentRoot);
    	   System.out.println( "name="+node.getNodeName()+" value="+node.getTextContent());
        return mObj;
      }
      else if( upnpClass.equals( "object.item.imageItem" ) )
      {
        //CDSImageItem imageItem = new CDSImageItem( node );
    	//System.out.println( node.getNodeName()+" "+node.getTextContent());
    	  MediaObject mObj = new MediaObject(node, upnpClass,parentRoot);
    	 System.out.println( "name="+node.getNodeName()+" value="+node.getTextContent());
       // System.out.println( imageItem.toXML( filter ) );
        return mObj;
      }
      else if( upnpClass.equals( "object.item.audioItem.musicTrack" ) )
      {
       // CDSMusicTrack musicTrack =
       //   new CDSMusicTrack( node );
    	  //System.out.println( node.getNodeName()+" "+node.getTextContent());
    	  MediaObject mObj = new MediaObject(node, upnpClass,parentRoot);
    	   System.out.println( "name="+node.getNodeName()+" value="+node.getTextContent());
        return mObj;
      }
      else if( upnpClass.equals( "object.item.audioItem" ) )
      {
    //    CDSAudioItem audioItem =
    //      new CDSAudioItem( node );
    	 // System.out.println( node.getNodeName()+" "+node.getTextContent());
    	  MediaObject mObj = new MediaObject(node, upnpClass,parentRoot);
    	   System.out.println( "name="+node.getNodeName()+" value="+node.getTextContent());
        return mObj;
      }
      else if( upnpClass.equals( "object.item" ) )
      {
    	  MediaObject mObj = new MediaObject(node, upnpClass,parentRoot);
       // System.out.println( node.getNodeName()+" "+node.getTextContent());
        System.out.println( "name="+node.getNodeName()+" value="+node.getTextContent());
        return mObj;
      }
      else if( upnpClass.equals( "object.container.musicAlbum" ) )
      {
    	  MediaObject mObj = new MediaObject(node, upnpClass,parentRoot);
       //   new CDSMusicAlbum( node );
    	  //System.out.println( node.getNodeName()+" "+node.getTextContent());
    	   System.out.println( "name="+node.getNodeName()+" value="+node.getTextContent());
        return mObj;
      }
      else if( upnpClass.equals( "object.container.storageFolder" ) )
      {
    	  MediaObject mObj = new MediaObject(node, upnpClass,parentRoot);
       //   new CDSStorageFolder( node );
    	//  System.out.println( node.getNodeName()+" "+node.getTextContent());
    	   System.out.println( "name="+node.getNodeName()+" value="+node.getTextContent());
        return mObj;
      }
      else if( upnpClass.equals( "object.container" ) )
      {
    	  MediaObject mObj = new MediaObject(node, upnpClass,parentRoot);
    	  System.out.println( node.getNodeName()+" "+node.getTextContent());
    	 //  System.out.println( "name="+node.getNodeName()+" value="+node.getTextContent());
        return mObj;
      }
      else
      {
    	  MediaObject mObj = new MediaObject(node, upnpClass,parentRoot);
        System.out.println("Unsupported UPNP object type '" + upnpClass + "'" );
      //  System.out.println( node.getNodeName()+" "+node.getTextContent());
        System.out.println( "name="+node.getNodeName()+" value="+node.getTextContent());
       
        return mObj;
      }

      
      
    }


/**
 * @return the mediaResponseObject
 */
public MediaResponseObject getMediaResponseObject() {
	return mediaResponseObject;
}


/**
 * @param mediaResponseObject the mediaResponseObject to set
 */
public void setMediaResponseObject(MediaResponseObject mediaResponseObject) {
	this.mediaResponseObject = mediaResponseObject;
}
 

    
}      
    

					  

