/* Bastet Test Package, some parts derived from cybergarage project, requires the cybergarage upnp
 *libraries. Released under Gnu license
 */
package com.mcv.tests;

import com.mcv.upnp.CdsObjects;
import org.cybergarage.upnp.*;
import org.cybergarage.upnp.media.*;
import org.cybergarage.upnp.media.player.MediaPlayer;
import org.cybergarage.upnp.media.server.object.ContentNode;
import org.cybergarage.upnp.ssdp.*;
import org.cybergarage.upnp.device.*;
import org.cybergarage.upnp.DeviceList.*;
import org.cybergarage.upnp.event.*;
import java.io.OutputStreamWriter;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.apache.commons.jxpath.*;
import org.apache.commons.jxpath.xml.DocumentContainer;
import java.util.Iterator;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.traversal.NodeIterator;
import org.xml.sax.InputSource;


public class MpTestDiscover extends MediaPlayer implements  NotifyListener, EventListener, SearchResponseListener ,  DeviceChangeListener {
    
    
    public MpTestDiscover() {
        addNotifyListener(this);
        addSearchResponseListener(this);
        addEventListener(this);
        addDeviceChangeListener( this );
        
        
        
    }
    ////////////////////////////////////////////////
    //	Frame
    ////////////////////////////////////////////////
    
    
    private static DeviceList UpnpDeviceList = null;
    private MpTestBrowse browseTest = null;
    
    
    ////////////////////////////////////////////////
    //	Listener
    ////////////////////////////////////////////////
    
    public void deviceNotifyReceived(SSDPPacket packet) {
        System.out.println(packet.toString());
        
        if (packet.isDiscover() == true) {
            String st = packet.getST();
            printConsole("ssdp:discover : ST = " + st);
        } else if (packet.isAlive() == true) {
            String usn = packet.getUSN();
            String nt = packet.getNT();
            String url = packet.getLocation();
            printConsole("ssdp:alive : uuid = " + usn + ", NT = " + nt + ", location = " + url);
        } else if (packet.isByeBye() == true) {
            String usn = packet.getUSN();
            String nt = packet.getNT();
            printConsole("ssdp:byebye : uuid = " + usn + ", NT = " + nt);
        }
        
    }
    
    public void deviceSearchResponseReceived(SSDPPacket packet) {
        String uuid = packet.getUSN();
        String st = packet.getST();
        String url = packet.getLocation();
        printConsole("device search res : uuid = " + uuid + ", ST = " + st + ", location = " + url);
        
    }
    
    public void eventNotifyReceived(String uuid, long seq, String name, String value) {
        printConsole("event notify : uuid = " + uuid + ", seq = " + seq + ", name = " + name + ", value =" + value);
    }
    
    
    public void deviceAdded( Device dev ) {
        
        printConsole("new device added " + dev.getFriendlyName());
        
        ContentNode content = super.getContentDirectory(dev);
        
        
     /*   if (dev.getDeviceType().equals("urn:schemas-upnp-org:device:MediaServer:1") ) {
            
            //     printConsole("found 1 mediaserver " + dev.getDeviceType());
            //}
            printConsole("found 1 mediadevice  " + dev.getDeviceType());
            UpnpDeviceList.add(dev);
            //urn:philips-com:device:PhilipsMediaServer
        } else
            
        {
            // Check embedded devices
            DeviceList devList = dev.getDeviceList();
            int devCnt = devList.size();
            
            for (int n = 0; n < devCnt; n++) {
                Device embeddedDev = devList.getDevice(n);
                
                System.out.println("  Checking embedded device " + n);
                System.out.println(" deviceType: " + embeddedDev.getDeviceType());
                System.out.println(" friendlyName: " + embeddedDev.getFriendlyName());
                
                // Set location field in embedded device for benefit of URLBase
                // logic
                embeddedDev.setLocation(dev.getLocation());
                
                if (embeddedDev.getDeviceType().indexOf("MediaServer") >= 0) {
                    printConsole("found embedded server  " + dev.getDeviceType());
                    UpnpDeviceList.add(dev);
                }
            }
            
        }
        
       
        
        if (dev.getFriendlyName().indexOf("TwonkyVision") > 0) {
            
            // if (dev.getFriendlyName().indexOf("D-Link") > 0) {
            // if (dev.getDeviceType().indexOf("PhilipsMediaServer") > 0) {
            printConsole("found target mediaserver  " + dev.getFriendlyName());
            System.out.println("service list" + dev.getServiceList());
            browseTest = new MpTestBrowse();
            
            // browseMetaData(dev, "0", "*", 0, 0, "");
            
            Document testDom = browseTest.browseMetaData(dev, "0","*",0,0,"");
            System.out.println(testDom.getFirstChild().toString());
            //this.PrintDom(testDom);
            
            //browseDirectChildren(dev, objectID, "*", 0, 0, "");
            testDom = browseTest.browseDirectChildren(dev, "3","*",0,0,"");
            System.out.println(testDom.getFirstChild().toString());
            DomUtilities printdd = new DomUtilities();
            printdd.printDOM(testDom, System.out);
            
            //browseDirectChildren(dev, objectID, "*", 0, 0, "");
            testDom = browseTest.browseDirectChildren(dev, "3","*",0,0,"");
            System.out.println(testDom.getFirstChild().toString());
            this.PrintDom(testDom);
            
            //browseDirectChildren(dev, objectID, "*", 0, 0, "");
            testDom = browseTest.browseDirectChildren(dev, "3$51","*",0,0,"");
            System.out.println(testDom.getFirstChild().toString());
            this.PrintDom(testDom);
            
            //browseDirectChildren(dev, objectID, "*", 0, 0, "");
            testDom = browseTest.browseDirectChildren(dev, "3$51$1207959556","*",0,0,"");
            System.out.println(testDom.getFirstChild().toString());
            this.PrintDom(testDom);
            
            
            
             
            int charVal = 92;
                char aChar  = (char)charVal;
             
             
               //browseDirectChildren(dev, objectID, "*", 0, 0, "");
            testDom = browseTest.browseDirectChildren(dev, "0" + aChar + "Movie" + aChar,"*",0,0,"");
            this.PrintDom(testDom);
             
             testDom = browseTest.browseDirectChildren(dev, "0" + aChar + "Movie" + aChar + "All%20Videos" + aChar,"*",0,0,"");
            this.PrintDom(testDom);
             
             
            
            
        }
        
        
        */
        
        
    }
    
    
    public void printConsole(String msg) {
        System.out.println(msg );
    }
    
    
    public void deviceRemoved( Device dev ) {
        
        printConsole("A device removed " + dev.getFriendlyName());
        
        
        
    }
    
    
    private void PrintDom( Document doc ) {
        
        
        try {
            // Set up an identity transformer to use as serializer.
            Transformer serializer = TransformerFactory.newInstance().newTransformer();
            serializer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            String xpath = "/";
            // Use the simple XPath API to select a nodeIterator.
            System.out.println("Querying DOM using "+xpath);
            NodeIterator nl = XPathAPI.selectNodeIterator(doc, xpath);
            
            // Serialize the found nodes to System.out.
            System.out.println("<output>");
            
            Node n;
            while ((n = nl.nextNode())!= null) {
                if (isTextNode(n)) {
                    // DOM may have more than one node corresponding to a
                    // single XPath text node.  Coalesce all contiguous text nodes
                    // at this level
                    StringBuffer sb = new StringBuffer(n.getNodeValue());
                    for (
                            Node nn = n.getNextSibling();
                    isTextNode(nn);
                    nn = nn.getNextSibling()
                    ) {
                        sb.append(nn.getNodeValue());
                    }
                    System.out.print(sb);
                } else {
                    serializer.transform(new DOMSource(n), new StreamResult(new OutputStreamWriter(System.out)));
                    
                }
                System.out.println();
            }
            System.out.println("</output>");
            
        }   catch (Exception e) {};
    }
    
    /** Decide if the node is text, and so must be handled specially */
    static boolean isTextNode(Node n) {
        if (n == null)
            return false;
        short nodeType = n.getNodeType();
        return nodeType == Node.CDATA_SECTION_NODE || nodeType == Node.TEXT_NODE;
    }
    
    
////////////////////////////////////////////////
//	main
////////////////////////////////////////////////
    
    public static void main(String args[]) {
        
        
        MpTestDiscover mpcontrol = new MpTestDiscover();
        UpnpDeviceList = new DeviceList();
        mpcontrol.start();
        
    }
    
    
    
}