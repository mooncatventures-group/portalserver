package com.mcv.util;


import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class W3cNode {


public void printNode( Node node, String indent )
{
  // Determine type of node
  
  switch( node.getNodeType() )
  {
    case Node.DOCUMENT_NODE:
      System.out.println("<xml version = \"1.0\">\n");
      Document doc = (Document)node;
      printNode( doc.getDocumentElement(), "" );
      break;

    case Node.ELEMENT_NODE:
      String name = node.getNodeName();
      System.out.print( indent + "<" + name );

      NamedNodeMap attributes = node.getAttributes();
      for( int n = 0 ; n < attributes.getLength() ; n++ )
      {
        Node current = attributes.item(n);
        System.out.print( " " + current.getNodeName() +
                          "=\"" + current.getNodeValue() +
                          "\"" );
      }

      NodeList children = node.getChildNodes();

      // If simple node, don't bother with newline between tags
      if( (children != null) && (children.getLength() > 0) &&
          (attributes.getLength() > 0 ) )
      {
        System.out.println( ">" );
      }
      else
      {
        System.out.println( ">" );
      }


      // Recurse on children

      if( children != null )
      {
        for( int n = 0 ; n < children.getLength() ; n++ )
        {
          printNode( children.item(n), indent + "  " );
        }
      }

      if( (children != null) && (children.getLength() > 0) &&
          (attributes.getLength() > 0 ) )
      {
        System.out.println( indent + "</" + name + ">" );
      }
      else
      {
        System.out.println( "</" + name + ">" );
      }

      break;

    case Node.TEXT_NODE:
    case Node.CDATA_SECTION_NODE:

      System.out.print( "("+ node.getNodeValue() + ")" );
      break;

    case Node.PROCESSING_INSTRUCTION_NODE:

      break;

    case Node.ENTITY_REFERENCE_NODE:

      break;

    case Node.DOCUMENT_TYPE_NODE:

      break;


  }

}
}


