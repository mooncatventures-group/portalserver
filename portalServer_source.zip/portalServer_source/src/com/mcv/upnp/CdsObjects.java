package com.mcv.upnp;
import java.io.FileInputStream;
import java.io.OutputStreamWriter;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.apache.commons.jxpath.*;
import org.apache.commons.jxpath.xml.DocumentContainer;
import java.util.Iterator;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.traversal.NodeIterator;
import org.xml.sax.InputSource;
import java.io.StringReader;


public class CdsObjects {
 
private Document xmlDom = null;

 
   public CdsObjects(String xmlString) {
         
    String xStr = xmlString.replaceAll("\"","'");
    xStr = xStr.replaceFirst("xmlns=","xmlns:d=");
     StringtoDom(xStr);
    
       
   }
    
  public CdsObjects() {
	// TODO Auto-generated constructor stub
}

private void StringtoDom(String xmlString ) {
        
        
        DocumentBuilderFactory factory =
                DocumentBuilderFactory.newInstance();
        try {
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.parse(new InputSource(new StringReader(xmlString)));
        this.xmlDom = document;
        }
      catch (Exception ex) { 
      }   
        
     
    
  
  }
  
  public Document getDomDoc () {
     
     return xmlDom;
    
 }
  
  public void PrintDom( Document doc ) {
      
      
      try {
          // Set up an identity transformer to use as serializer.
          Transformer serializer = TransformerFactory.newInstance().newTransformer();
          serializer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
          String xpath = "./*";
          // Use the simple XPath API to select a nodeIterator.
          System.out.println("Querying DOM using "+xpath);
          NodeIterator nl = XPathAPI.selectNodeIterator(doc, xpath);
          
          // Serialize the found nodes to System.out.
          System.out.println("<output>");
          
          Node n;
          while ((n = nl.nextNode())!= null) {
              if (isTextNode(n)) {
                  // DOM may have more than one node corresponding to a
                  // single XPath text node.  Coalesce all contiguous text nodes
                  // at this level
                  StringBuffer sb = new StringBuffer(n.getNodeValue());
                  for (
                          Node nn = n.getNextSibling();
                  isTextNode(nn);
                  nn = nn.getNextSibling()
                  ) {
                      sb.append(nn.getNodeValue());
                  }
                  System.out.print(sb);
              } else {
                  serializer.transform(new DOMSource(n), new StreamResult(new OutputStreamWriter(System.out)));
                  
              }
              System.out.println();
          }
          System.out.println("</output>");
          
      }   catch (Exception e) {};
  }
  
  
  
  /** Decide if the node is text, and so must be handled specially */
  public static boolean isTextNode(Node n) {
      if (n == null)
          return false;
      short nodeType = n.getNodeType();
      return nodeType == Node.CDATA_SECTION_NODE || nodeType == Node.TEXT_NODE;
  }
  
  
 
  
  
  public String toString() {
  
return toString();
  
  }
} 

