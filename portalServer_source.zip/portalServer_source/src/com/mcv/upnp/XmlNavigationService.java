/**
 * 
 */
package com.mcv.upnp;

import java.io.IOException;
import java.io.DataOutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;

import javax.servlet.http.HttpServletResponse;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.dom.DOMResult;
import javax.xml.xpath.XPathFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import java.io.ByteArrayInputStream;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;

public class XmlNavigationService {
	/**
	 * @author HP_Owner
	 * 
	 */
	public XmlNavigationService(String xml) {
		domToStructure(xml);

	}

	private void domToStructure(String xml) {
		StreamSource source = new StreamSource(new ByteArrayInputStream(xml
				.getBytes()));
		DOMResult dom_result = new DOMResult();
	
		try {
			Transformer trans = TransformerFactory.newInstance()
					.newTransformer();
			trans.transform(source, dom_result);
			XPathFactory xpf = XPathFactory.newInstance();
			XPath xp = xpf.newXPath();
			NodeList list = (NodeList) xp.evaluate("//*", dom_result
					.getNode(), XPathConstants.NODESET);
			int len = list.getLength();
			for (int i = 0; i < len; i++) {
				Node node = list.item(i);
				if (node != null) {
					System.out.println("siblings "+
							node.getFirstChild().getNextSibling() + "="
									+ node.getFirstChild().getNextSibling().getTextContent());
					

				}
			}
		} catch (TransformerConfigurationException e) {
			System.err.println(e);
		} catch (TransformerException e) {
			System.err.println(e);
		} catch (XPathExpressionException e) {
			System.err.println(e);
		
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String xml = "<DIDL-Lite xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite\" xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:upnp=\"urn:schemas-upnp-org:metadata-1-0/upnp\"><item id=\"10\" parentID=\"1\" restricted=\"false\" > <upnp:class>object.item.videoItem.movie</upnp:class> <dc:title>Terminator</dc:title> <upnp:genre>Action</upnp:genre> <upnp:rating>Action</upnp:rating> <upnp:actor>Arnold</upnp:actor> <upnp:director>Arnold</upnp:director> <dc:description>Machines rule the future</dc:description></item>"
				+ "<item id=\"11\" parentID=\"1\" restricted=\"false\" > <upnp:class>object.item.videoItem.movie</upnp:class> <dc:title>Terminator</dc:title> <upnp:genre>Action</upnp:genre> <upnp:rating>Action</upnp:rating> <upnp:actor>Arnold</upnp:actor> <upnp:director>Arnold</upnp:director> <dc:description>Machines rule the future</dc:description></item></DIDL-Lite> ";
	
	
	
	}

}
