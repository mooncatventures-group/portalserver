
package com.mcv.upnp;

import com.apple.dnssd.DNSSDException;
import org.cybergarage.upnp.*;
import org.cybergarage.upnp.media.player.action.*;
import org.cybergarage.upnp.ssdp.*;
import org.cybergarage.upnp.device.*;
import org.cybergarage.upnp.DeviceList.*;
import org.cybergarage.upnp.event.*;
import org.cybergarage.upnp.media.player.*;
import java.io.OutputStreamWriter;
import java.net.InetAddress;

import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.apache.commons.jxpath.*;
import org.apache.commons.jxpath.xml.DocumentContainer;
import java.util.Iterator;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.traversal.NodeIterator;
import org.xml.sax.InputSource;


public class MpDomUtil  {
    
    
    
    public MpDomUtil() {
      
        
    }
    
    
    public void PrintDom( Document doc , HttpServletResponse resp ) {
        
        
        try {
            // Set up an identity transformer to use as serializer.
            Transformer serializer = TransformerFactory.newInstance().newTransformer();
            serializer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            String xpath = "./*";
            // Use the simple XPath API to select a nodeIterator.
            resp.getWriter().println("Querying DOM using "+xpath);
            NodeIterator nl = XPathAPI.selectNodeIterator(doc, xpath);
            
            // Serialize the found nodes to System.out.
            resp.getWriter().println("<output>");
            
            Node n;
            while ((n = nl.nextNode())!= null) {
                if (isTextNode(n)) {
                    // DOM may have more than one node corresponding to a
                    // single XPath text node.  Coalesce all contiguous text nodes
                    // at this level
                    StringBuffer sb = new StringBuffer(n.getNodeValue());
                    for (
                            Node nn = n.getNextSibling();
                    isTextNode(nn);
                    nn = nn.getNextSibling()
                    ) {
                        sb.append(nn.getNodeValue());
                    }
                    System.out.print(sb);
                } else {
                    serializer.transform(new DOMSource(n), new StreamResult(resp.getWriter()));
                    
                }
                resp.getWriter().println();
            }
            resp.getWriter().println("</output>");
            
        }   catch (Exception e) {};
    }
    
    /** Decide if the node is text, and so must be handled specially */
    static boolean isTextNode(Node n) {
        if (n == null)
            return false;
        short nodeType = n.getNodeType();
        return nodeType == Node.CDATA_SECTION_NODE || nodeType == Node.TEXT_NODE;
    }
    
    
    

    
    
}