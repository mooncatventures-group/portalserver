package com.mcv.server;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.UnknownHostException;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import javax.swing.*;

import com.apple.eawt.*;
import com.mcv.servlet.MediaServer;

public class MediaClient extends JFrame {
    
    private Font font = new Font("serif", Font.ITALIC+Font.BOLD, 14);
    protected ResourceBundle resbundle;
    protected AboutBox aboutBox;
    protected PrefPane prefs;
    private Application fApplication = Application.getApplication();
    protected Action  closeAction;
    protected Action  aboutAction;
    protected Action prefAction;
    private String os = null;
    private int localport = 0;
    public int port = 0;
    static Logger log = Logger.getLogger("MediaClient");
    
    static final JMenuBar mainMenuBar = new JMenuBar();
    protected JMenu fileMenu;
    protected JMenu helpMenu;
    
    public MediaClient() {
        
        
        super("");
        // The ResourceBundle below contains all of the strings used in this
        // application.  ResourceBundles are useful for localizing applications.
        // New localities can be added by adding additional properties files.
        resbundle = ResourceBundle.getBundle("com.mcv.server.MediaClientstrings", Locale.getDefault());
        setTitle(resbundle.getString("frameConstructor"));
        this.getContentPane().setLayout(null);
        
       
		try {
			ServerSocket serverPort = new ServerSocket(0);
			port = serverPort.getLocalPort();
			serverPort.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    	
        createActions();
        addMenus();
        if (isRunningOnOSX())  {
            
            fApplication.setEnabledPreferencesMenu(true);
            fApplication.addApplicationListener(new com.apple.eawt.ApplicationAdapter() {
                public void handleAbout(ApplicationEvent e) {
                    if (aboutBox == null) {
                        aboutBox = new AboutBox();
                    }
                    about(e);
                    e.setHandled(true);
                }
                public void handleOpenApplication(ApplicationEvent e) {
                }
                
                public void handlePreferences(ApplicationEvent e) {
                    if (prefs == null) {
                        prefs = new PrefPane(port);
                    }
                    preferences(e);
                }
                
                public void handleQuit(ApplicationEvent e) {
                    quit(e);
                }
            });
        }else {
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            addWindowListener(new WindowAdapter() {
                public void windowClosing(WindowEvent e) {
                    exitForm(e);
                }
            });
            setJMenuBar(mainMenuBar);
            
        }
        setSize(310, 150);
        setVisible(true);     
            
        String pattern= "%d{ISO8601}::%p: %C{1}:  %m %n";		
		ConsoleAppender appender = new ConsoleAppender(new PatternLayout(pattern));		
		log.addAppender(appender);
		log.info("OS Detected:"+System.getProperty("os.name"));
		log.setLevel(Level.DEBUG);
		log.info("Started Logger");
		
		MediaServer mediaServer;    
		// use first interface as address
		//log.info("No address provided, will choose first interface");
		String externalAddress = resbundle.getString("localAddress");
		log.info("parm externalAddress: "+externalAddress);
		mediaServer=new MediaServer(externalAddress,port);
  
  }        
    
    
    public void about(ApplicationEvent e) {
        aboutBox.setResizable(false);
        aboutBox.setVisible(true);
        aboutBox.show();
    }
    
    public void preferences(ApplicationEvent e) {
        prefs.setResizable(false);
        prefs.setVisible(true);
        prefs.show();
    }
    
    public void quit(ApplicationEvent e) {
        System.exit(0);
    }
    
    public void createActions() {
        int shortcutKeyMask = Toolkit.getDefaultToolkit().getMenuShortcutKeyMask();
        
        //Create actions that can be used by menus, buttons, toolbars, etc.
        
        closeAction = new closeActionClass( resbundle.getString("closeItem"),
                KeyStroke.getKeyStroke(KeyEvent.VK_C, shortcutKeyMask) );
        aboutAction = new aboutActionClass( this,resbundle.getString("aboutItem"),
                KeyStroke.getKeyStroke(KeyEvent.VK_H, shortcutKeyMask) );
        prefAction = new prefActionClass ( resbundle.getString("prefItem"),
                KeyStroke.getKeyStroke(KeyEvent.VK_P, shortcutKeyMask) );
        
    }
    
    public void addMenus() {
        
        fileMenu = new JMenu(resbundle.getString("fileMenu"));
        if (isRunningOnOSX()) {
            fileMenu.add(new JMenuItem(closeAction));
            mainMenuBar.add(fileMenu);
        }
        if (!isRunningOnOSX())  {
            fileMenu.add(new JMenuItem(prefAction));
            fileMenu.add(new JMenuItem(closeAction));
            mainMenuBar.add(fileMenu);
            helpMenu = new JMenu(resbundle.getString("helpMenu"));
            helpMenu.add(new JMenuItem(aboutAction));
            mainMenuBar.add(helpMenu);
        }
        
    }
    
    public void paint(Graphics g) {
        
        try {
            super.paint(g);
            g.setColor(Color.blue);
            g.setFont(font);
            g.drawString(resbundle.getString("message") + " on local port " + this.getDnssdPort(), 40, 80);
        }  catch (Exception e) {
            e.printStackTrace();
            
        }
    }
    
    
    
    
    public class closeActionClass extends AbstractAction {
        public closeActionClass(String text, KeyStroke shortcut) {
            super(text);
            putValue(ACCELERATOR_KEY, shortcut);
        }
        public void actionPerformed(ActionEvent e) {
            System.out.println("Close...");
            System.exit(0);
        }
    }
    
    public class aboutActionClass extends AbstractAction {
        MediaClient controller;
        public aboutActionClass(MediaClient _controller , String text, KeyStroke shortcut) {
            super(text);
            controller = _controller;
            putValue(ACCELERATOR_KEY, shortcut);
        }
        public void actionPerformed(ActionEvent e) {
            if (aboutBox == null) {
                aboutBox = new AboutBox();
            }
            aboutBox.setResizable(false);
            aboutBox.setVisible(true);
            aboutBox.show();
            controller.repaint();           
           
            
        }
    }
    
    public class prefActionClass extends AbstractAction {
        MediaClient controller;
        public prefActionClass(String text, KeyStroke shortcut) {
            super(text);
            putValue(ACCELERATOR_KEY, shortcut);
        }
        public void actionPerformed(ActionEvent e) {
            if (prefs == null) {
                prefs = new PrefPane(port);
            }
            prefs.setResizable(false);
            prefs.setVisible(true);
            prefs.show();
           
            
            
            
            
        }
    }
   
    
    
    
    
    public  boolean isRunningOnOSX() {
        
        if( os == null ) {
            os = System.getProperty("os.name");
        }
        
        
        if( os.toLowerCase().indexOf("os x") >= 0 )
            return true;
        
        return false;
    }
    private void exitForm(WindowEvent e) {
    }
    
    public void setDnssdPort(int dnssDport) {
        this.port = dnssDport;
    }
    
    public int getDnssdPort() {
        return this.port;
    }
    
    public static void main(String args[]) {
        new MediaClient();
    }
    
}