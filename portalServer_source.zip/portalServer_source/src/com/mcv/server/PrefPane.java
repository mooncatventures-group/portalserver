package com.mcv.server;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class PrefPane extends JFrame {
    protected JButton okButton;
    protected JButton cancelButton;
    protected JLabel prefsText;
    protected JprefForm jprefform;
    protected int port;

    public PrefPane(int _port)
    {
		super();
                
         
        this.port = _port;
        this.getContentPane().setLayout(new BorderLayout(10, 10));
        prefsText = new JLabel ("0 for auto Port selection");
       // JPanel textPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
       // textPanel.add(prefsText);
       // this.getContentPane().add (textPanel, BorderLayout.NORTH);
		
        jprefform = new JprefForm(this);
       
        this.add (jprefform, BorderLayout.NORTH);
        cancelButton = new JButton("Close");
        okButton = new JButton("OK");
        okButton.setEnabled(false);
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        buttonPanel.add(prefsText);
        buttonPanel.add (cancelButton);
        buttonPanel.add (okButton);
           cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent newEvent) {
				setVisible(false);
			}	
		});
        okButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent newEvent) {
				prefsText.setText("notImplemented");
			}	
		});
        this.add(buttonPanel, BorderLayout.SOUTH);
        
		setSize(390, 229);
		setLocation(20, 40);
    }
    
    public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public void setEnableOk(boolean value) {
        okButton.setEnabled(value);
        this.repaint();
    }
    
}