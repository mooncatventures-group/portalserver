package com.mcv.server;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.text.NumberFormat;
import java.io.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.ActionListener;
import javax.swing.InputVerifier;
/*
 * Created by JFormDesigner on Fri Jan 19 21:08:12 EST 2007
 */



/**
 */
public class JprefForm  extends JPanel {
    boolean inputCheck = false;
    PrefPane prefpane;
    protected ResourceBundle resbundle;
    
    public JprefForm(PrefPane _prefpane) {
        prefpane = _prefpane;
        initComponents();
    }
    
    private void serverNameActionPerformed(ActionEvent e) {
        
    }
    
    private void remoteHostActionPerformed(ActionEvent e) {
        // TODO add your code here
    }
    
    private void remotePortActionPerformed(ActionEvent e) {
        // TODO add your code here
    }
    
    private void localportActionPerformed(ActionEvent e) {
        // TODO add your code here
    }
    
    
    
    private void initComponents() {
        
        panel3 = new JPanel();
        serverlbl = new JLabel();
        serverName = new JTextField();
        remoteHostlbl = new JLabel();
        remoteHost = new JTextField();
        remotePortlbl = new JLabel();
        remotePort = new JTextField();
        localPortlbl = new JLabel();
        localport = new JTextField();
        this.getConfig();
        
        
        
        
        
    
        
        
        
        
        
        InputVerifier verifier = new InputVerifier() {
            public boolean verify(JComponent comp) {
                JTextField textField = (JTextField) comp;
                if (serverName.getText().length()>0 && remoteHost.getText().length() > 0 && remotePort.getText().length()>0 ) {
                    
                    prefpane.setEnableOk(false);
                    
                }else {
                    prefpane.setEnableOk(false);
                    
                }
                
                return true;
            }
        };
        
        
        
        serverName.setInputVerifier(verifier);
        serverName.setEditable(false);
        remoteHost.setInputVerifier(verifier);
        remoteHost.setEditable(false);
        remotePort.setInputVerifier(verifier);
        remotePort.setEditable(false);
        localport.setInputVerifier(verifier);
        localport.setEditable(false);
        
        //======== panel2 ========
        {
            this.setLayout(new GridBagLayout());
            ((GridBagLayout)this.getLayout()).columnWidths = new int[] {0, 0};
            ((GridBagLayout)this.getLayout()).rowHeights = new int[] {0, 0, 0, 0, 0};
            ((GridBagLayout)this.getLayout()).columnWeights = new double[] {1.0, 1.0E-4};
            ((GridBagLayout)this.getLayout()).rowWeights = new double[] {0.0, 1.0, 0.0, 0.0, 1.0E-4};
            
            //======== panel3 ========
            {
                panel3.setBorder(new CompoundBorder(
                        new TitledBorder("Bridge Configuration"),
                        new EmptyBorder(5, 5, 5, 5)));
                panel3.setLayout(new GridBagLayout());
                ((GridBagLayout)panel3.getLayout()).columnWidths = new int[] {0, 155, 0, 0};
                ((GridBagLayout)panel3.getLayout()).rowHeights = new int[] {0, 0, 0, 0, 0};
                ((GridBagLayout)panel3.getLayout()).columnWeights = new double[] {0.0, 1.0, 0.0, 1.0E-4};
                ((GridBagLayout)panel3.getLayout()).rowWeights = new double[] {1.0, 0.0, 0.0, 0.0, 1.0E-4};
                
                //---- serverlbl ----
                serverlbl.setText("Server Name:");
                panel3.add(serverlbl, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0,
                        GridBagConstraints.CENTER, GridBagConstraints.BOTH,
                        new Insets(0, 0, 5, 5), 0, 0));
                
                //---- serverName ----
                
                serverName.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        serverNameActionPerformed(e);
                    }
                });
                panel3.add(serverName, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0,
                        GridBagConstraints.CENTER, GridBagConstraints.BOTH,
                        new Insets(0, 0, 5, 5), 0, 0));
                
                //---- remoteHostlbl ----
                remoteHostlbl.setText("Local Address");
                panel3.add(remoteHostlbl, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0,
                        GridBagConstraints.CENTER, GridBagConstraints.BOTH,
                        new Insets(0, 0, 5, 5), 0, 0));
                
                //---- remoteHost ----
                remoteHost.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        remoteHostActionPerformed(e);
                    }
                });
                panel3.add(remoteHost, new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0,
                        GridBagConstraints.CENTER, GridBagConstraints.BOTH,
                        new Insets(0, 0, 5, 5), 0, 0));
                
                //---- remotePortlbl ----
                remotePortlbl.setText("External Address");
                panel3.add(remotePortlbl, new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0,
                        GridBagConstraints.CENTER, GridBagConstraints.BOTH,
                        new Insets(0, 0, 5, 5), 0, 0));
                
                //---- remotePort ----
                remotePort.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        remotePortActionPerformed(e);
                    }
                });
                panel3.add(remotePort, new GridBagConstraints(1, 2, 1, 1, 0.0, 0.0,
                        GridBagConstraints.CENTER, GridBagConstraints.BOTH,
                        new Insets(0, 0, 5, 5), 0, 0));
                
                //---- localPortlbl ----
                localPortlbl.setText("Local Port:");
                panel3.add(localPortlbl, new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0,
                        GridBagConstraints.CENTER, GridBagConstraints.BOTH,
                        new Insets(0, 0, 0, 5), 0, 0));
                
                //---- localport ----
                localport.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        localportActionPerformed(e);
                    }
                });
                panel3.add(localport, new GridBagConstraints(1, 3, 1, 1, 0.0, 0.0,
                        GridBagConstraints.CENTER, GridBagConstraints.BOTH,
                        new Insets(0, 0, 0, 5), 0, 0));
            }
            this.add(panel3, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0,
                    GridBagConstraints.CENTER, GridBagConstraints.BOTH,
                    new Insets(0, 0, 5, 0), 0, 0));
        }
        
        
        
    }
    
    private void getConfig()  {
        
      
          
            
            resbundle = ResourceBundle.getBundle("com.mcv.server.MediaClientstrings", Locale.getDefault());
            
            this.remoteHost.setText(resbundle.getString("localAddress"));
            this.serverName.setText(resbundle.getString("serverName"));
            this.remotePort.setText(resbundle.getString("externalAddress"));
            this.localport.setText(prefpane.getPort()+"");
            
       
        
    }
    
  
    
    
	// JFormDesigner - Variables declaration - DO NOT MODIFY//GEN-BEGIN:variables
	// Generated using JFormDesigner non-commercial license
	private JPanel panel2;
	private JPanel panel3;
	private JLabel serverlbl;
	private JTextField serverName;
	private JLabel remoteHostlbl;
	private JTextField remoteHost;
	private JLabel remotePortlbl;
	private JTextField remotePort;
	private JLabel localPortlbl;
	private JTextField localport;
	// JFormDesigner - End of variables declaration//GEN-END:variables
}
