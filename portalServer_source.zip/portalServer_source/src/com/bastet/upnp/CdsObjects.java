package com.bastet.upnp;
import java.io.FileInputStream;
import java.io.OutputStreamWriter;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.apache.commons.jxpath.*;
import org.apache.commons.jxpath.xml.DocumentContainer;
import java.util.Iterator;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.traversal.NodeIterator;
import org.xml.sax.InputSource;
import java.io.StringReader;


public class CdsObjects {
 
private Document xmlDom = null;

 
   public CdsObjects(String xmlString) {
         
    String xStr = xmlString.replaceAll("\"","'");
    xStr = xStr.replaceFirst("xmlns=","xmlns:d=");
     StringtoDom(xStr);
    
       
   }
    
  private void StringtoDom(String xmlString ) {
        
        
        DocumentBuilderFactory factory =
                DocumentBuilderFactory.newInstance();
        try {
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.parse(new InputSource(new StringReader(xmlString)));
        this.xmlDom = document;
        }
      catch (Exception ex) { 
      }   
        
     
    
  
  }
  
  public Document getDomDoc () {
     
     return xmlDom;
    
 }
  
  
 
  
 
  
  
  public String toString() {
  
return toString();
  
  }
} 

