package com.bastet.control;
import java.net.*;
import java.io.*;
import java.util.*;
import java.util.ArrayList;
import java.util.Iterator;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;
import org.apache.commons.jxpath.*;
import org.apache.commons.jxpath.JXPathException;
import org.apache.commons.jxpath.xml.DocumentContainer;
import java.net.*;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import com.bastet.control.*;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.traversal.NodeIterator;
import org.xml.sax.InputSource;
import java.util.logging.Logger;
import org.cybergarage.util.*;
import org.cybergarage.upnp.*;
import org.cybergarage.upnp.ssdp.*;
import org.cybergarage.upnp.device.*;
import org.cybergarage.upnp.event.*;
import java.io.File;
import java.io.IOException;

import org.w3c.dom.Document;
import org.w3c.dom.DOMException;



public class IreqHandler implements Runnable {
    
    private static List pool = new LinkedList();
    private File documentRootDirectory;
    private String indexFileName = "StartIPagehtml.html";
    private DeviceList upnpdevicelist;
    private HtmlTemplate htmltemplates;
    private HtmlResults htmlresults;
    private Device mediaDevice;
    private  MpBrowse mpbrowse;
    private Document upnpdoc;
    private JsonRequest jsonRequest;
    private JsonRequest jsonRequestHeader;
    private XmlRequest xmlRequest;
    private HtmlRequest htmlRequest;
    private XmlRequest xmlRequestHeader;
    private boolean useJson = false;
    private boolean useHtml = false;
    private boolean usePlayer = false;
    
    
    public IreqHandler(DeviceList upnpDeviceList, HtmlTemplate htmltemplate) {
        
        this.upnpdevicelist = upnpDeviceList;
        this.htmltemplates = htmltemplate;
        
        
        
        
        documentRootDirectory = new File(System.getProperty("user.dir"));
        
        if (documentRootDirectory.isFile()) {
            throw new IllegalArgumentException(
                    "documentRootDirectory must be a directory, not a file");
        }
        this.documentRootDirectory = documentRootDirectory;
        try {
            this.documentRootDirectory
                    = documentRootDirectory.getCanonicalFile();
        } catch (IOException ex) {
        }
        if (indexFileName != null) this.indexFileName = indexFileName;
    }
    
    public static Document doc;
    
    public static void processRequest(Socket request) {
        
        synchronized (pool) {
            pool.add(pool.size(), request);
            pool.notifyAll();
        }
        
    }
    
    public void run() {
        
        // for security checks
        String root = documentRootDirectory.getPath();
        
        while (true) {
            Socket connection;
            synchronized (pool) {
                while (pool.isEmpty()) {
                    try {
                        pool.wait();
                    } catch (InterruptedException ex) {
                    }
                }
                connection = (Socket) pool.remove(0);
            }
            
            try {
                String filename;
                String contentType;
                OutputStream raw = new BufferedOutputStream(
                        connection.getOutputStream()
                        );
                Writer out = new OutputStreamWriter(raw);
                //    Reader in = new InputStreamReader(
                //              new BufferedInputStream(
                //                 connection.getInputStream()
                //             ),"ASCII"
                //          );
                BufferedReader in = new BufferedReader(
                        new InputStreamReader(connection.getInputStream()));
                
                
                StringBuffer requestLine = new StringBuffer();
                int c;
                while (true) {
                    c = in.read();
                    if (c == '\r' || c == '\n') break;
                    requestLine.append((char) c);
                }
                
                String get = requestLine.toString();
                
                // log the request
                System.out.println(in.toString());
                Iterator itx = null;
                Iterator itx1 = null;
                StringTokenizer st = new StringTokenizer(get);
                String method = st.nextToken();
                String version = "";
                String xpath=null;
                String xitemId=null;
                if (method.equals("GET")) {
                    filename = st.nextToken();
                    if (filename.indexOf("?") > 0)  {
                        int xpathpos = filename.indexOf("?");
                        xpath = filename.substring(xpathpos+1);
                        if (filename.indexOf("?h") > 0)  {
                            xpath = filename.substring(xpathpos+2);
                            useHtml=true;
                        }
                     if (filename.indexOf("?m") > 0)  {
                            //objectItemId
                            xitemId = filename.substring(xpathpos+2).split("-") [0];
                            //parent
                            xpath = filename.substring(xpathpos+2).split("-") [1];
                            usePlayer=true;
                        }
                        
                       
                        
                         if (useHtml || usePlayer) {
                        
                            } else
                        if (useJson) {
                            JsonRequest jsonRequestHeader = new  JsonRequest(upnpdevicelist,htmltemplates,out);
                        } else {
                            XmlRequest xmlRequestHeader = new  XmlRequest(upnpdevicelist,htmltemplates,out);
                        }
                        
                        
                        mediaDevice = this.findDevice(filename.substring(0,xpathpos));
                        if (mediaDevice == null) {
                            System.out.println("device not available");
                        }else {
                            upnpdoc = browseServer(mediaDevice,xpath);
                            System.out.println("build dom doc " + xpath);
                            itx =  jxpathSummary(upnpdoc,xpath);
                            itx1 = jxpathDetail(upnpdoc, xpath);
                           
                            
                            
                            if (useHtml) {
                                HtmlRequest  htmlRequest = new  HtmlRequest(xpath,itx1,mediaDevice.getFriendlyName() , out);
                            } else
                                if (useJson) {
                                JsonRequest  jsonRequest = new  JsonRequest(itx,itx1,mediaDevice.getFriendlyName() , out);
                                } else 
                                 if (usePlayer) {
                                HtmlResults  htmlresults = new  HtmlResults(upnpdoc,xitemId,mediaDevice.getFriendlyName() , out);
                                } else {
                                XmlRequest  xmlRequest = new  XmlRequest(itx,itx1,mediaDevice.getFriendlyName(),xpath,out);
                                }
                            
                            
                        }
                        
                        break;
                    }
                    
                    
                    if (filename.endsWith("/")) {
                        
                        Iterator it = null;
                        ArrayList upnpDevice = new ArrayList();
                        for (int i=upnpdevicelist.size()-1; i>=0; i--) {
                            upnpDevice.add(upnpdevicelist.getDevice(i).getFriendlyName() + "!" +
                                    upnpdevicelist.getDevice(i).getDeviceType());
                        }
                        
                        it = upnpDevice.iterator();
                        
                        out.write(htmltemplates.getHtmlTemplate().toString());
                        
                        
                        //  out.write("<ul id='servers' title='Discovered Servers' selected='true'>\r\n");
                        String[] hrefStr = null;
                        if (it.hasNext()) {
                            String ref =  it.next().toString();
                            hrefStr = ref.split("!");
                            hrefStr[0] = this.stripSpecialChars(hrefStr[0]);
                            out.write("<li class='device' ><a href='#servers@nobody"  + "?'>" +  "UPNP Media Sources"  +  "</a></li>\r\n");
                              out.write("<li class='device' ><a href='#servers@nobody"  + "?'>" +  "Bonjour Sources"  +  "</a></li>\r\n");
                            out.write("<li class='device' ><a href='#servers@nobody"  + "?'>" +  "Other Sources"  +  "</a></li>\r\n");
                          
                            
                        }
                        out.write("</ul>\r\n");
                        out.write(htmltemplates.getfooterTemplate().toString());
                        out.flush();
                        break;
                    }
                    
                    
                    contentType = guessContentTypeFromName(filename);
                    if (st.hasMoreTokens()) {
                        version = st.nextToken();
                    }
                    
                    File theFile = new File(documentRootDirectory,
                            filename.substring(1,filename.length()));
                    if (theFile.canRead()
                    // Don't let clients outside the document root
                    && theFile.getCanonicalPath().startsWith(root)) {
                        DataInputStream fis = new DataInputStream(
                                new BufferedInputStream(
                                new FileInputStream(theFile)
                                )
                                );
                        byte[] theData = new byte[(int) theFile.length()];
                        fis.readFully(theData);
                        fis.close();
                        if (version.startsWith("HTTP ")) {  // send a MIME header
                            out.write("HTTP/1.0 200 OK\r\n");
                            Date now = new Date();
                            out.write("Date: " + now + "\r\n");
                            out.write("Server: JHTTP/1.0\r\n");
                            out.write("Content-length: " + theData.length + "\r\n");
                            out.write("Content-type: " + contentType + "\r\n\r\n");
                            
                            
                            
                            out.flush();
                        }  // end if
                        
                        // send the file; it may be an image or other binary data
                        // so use the underlying output stream
                        // instead of the writer
                        raw.write(theData);
                        
                        raw.flush();
                    }  // end if
                    else {  // can't find the file
                        if (version.startsWith("HTTP ")) {  // send a MIME header
                            out.write("HTTP/1.0 404 File Not Found\r\n");
                            Date now = new Date();
                            out.write("Date: " + now + "\r\n");
                            out.write("Server: JHTTP/1.0\r\n");
                            out.write("Content-type: text/html\r\n\r\n");
                        }
                        out.write("<HTML>\r\n");
                        out.write("<HEAD><TITLE>File Not Found</TITLE>\r\n");
                        out.write("</HEAD>\r\n");
                        out.write("<BODY>");
                        out.write("<H1>HTTP Error 404: File Not Found"+ filename + "</H1>\r\n");
                        out.write("</BODY></HTML>\r\n");
                        out.flush();
                    }
                } else {  // method does not equal "GET"
                    if (version.startsWith("HTTP ")) {  // send a MIME header
                        out.write("HTTP/1.0 501 Not Implemented\r\n");
                        Date now = new Date();
                        out.write("Date: " + now + "\r\n");
                        out.write("Server: JHTTP 1.0\r\n");
                        out.write("Content-type: text/html\r\n\r\n");
                    }
                    out.write("<HTML>\r\n");
                    out.write("<HEAD><TITLE>Not Implemented</TITLE>\r\n");
                    out.write("</HEAD>\r\n");
                    out.write("<BODY>");
                    out.write("<H1>HTTP Error 501: Not Implemented</H1>\r\n");
                    out.write("</BODY></HTML>\r\n");
                    out.flush();
                }
            } catch (IOException ex) {
            } finally {
                try {
                    connection.close();
                } catch (IOException ex) {}
            }
            
        } // end while
        
    } // end run
    
    
    /** Decide if the node is text, and so must be handled specially */
    public static boolean isTextNode(Node n) {
        if (n == null)
            return false;
        short nodeType = n.getNodeType();
        return nodeType == Node.CDATA_SECTION_NODE || nodeType == Node.TEXT_NODE;
    }
    
    private Device findDevice(String deviceName) {
        
        String friendlyName = null;
        deviceName = stripSpecialChars(deviceName);
        for (int i=upnpdevicelist.size()-1; i>=0; i--) {
            friendlyName = htmltemplates.cleanupServerHref(upnpdevicelist.getDevice(i).getFriendlyName());
            friendlyName = stripSpecialChars(friendlyName);
            System.out.println("friendlyName " + friendlyName + deviceName);
            if (friendlyName.indexOf(deviceName) > -1) {
                return upnpdevicelist.getDevice(i);
            }
            
            
        }
        return null;
    }
    
    private  String stripSpecialChars(String s) {
        String goodUrl =
                " abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        String result = "";
        for ( int i = 0; i < s.length(); i++ ) {
            if ( goodUrl.indexOf(s.charAt(i)) >= 0 )
                result += s.charAt(i);
        }
        return result;
    }
    
    
    private Document browseServer(Device dev, String objectID) {
        
        mpbrowse = new MpBrowse();
        
        // browseMetaData(dev, "0", "*", 0, 0, "");
        
        Document doc = mpbrowse.browseMetaData(dev, "0","*",0,0,"");
        this.PrintDom(doc);
        
        //browseDirectChildren(dev, objectID, "*", 0, 0, "");
        doc = mpbrowse.browseDirectChildren(dev, objectID ,"*",0,0,"");
        this.PrintDom(doc);
        return doc;
        
    }
    
    
    public  Iterator jxpathSummary(Document doc,String objectID) {
        
        //  String xpath = "/*/container[@parentID=" + "'" + objectID + "'" + "]/@parentID | ";
        //  xpath +="/*/container[@parentID=" + "'" + objectID + "'" + "]/@id | ";
        //  xpath += "/*/container[@parentID=" + "'" + objectID + "'" +"]/dc:title ";
        
        String  xpath = "/*/container/@parentID | /*/container/@id  | /*/container/upnp:class | /*/container/dc:title ";
        
        //String xpath = "/*/container[@parentID='0']/@parentID | /*/container[@parentID='0']/@id | /*/container[@parentID='0']/dc:title ";
        System.out.println("try jxpath now for objectid = " + objectID);
        System.out.println("this xpath " + xpath);
        
        JXPathContext context =
                JXPathContext.newContext(doc);
        
        Iterator it = context.iterate(xpath) ;
        return it;
        
    }
    
    public  Iterator jxpathDetail(Document doc,String objectID) {
        
        //  String xpath = "/*/container[@parentID=" + "'" + objectID + "'" + "]/@parentID | ";
        //  xpath +="/*/container[@parentID=" + "'" + objectID + "'" + "]/@id | ";
        //  xpath += "/*/container[@parentID=" + "'" + objectID + "'" +"]/dc:title ";
        
        //String  xpath = "/*/container/@parentID | /*/container/@id  | /*/container/upnp:class | /*/container/dc:title ";
        //String xpath = "/*/item/@id |  /*/item/dc:title | /*/item/res";
        String xpath = "/*/item/@id |  /*/item/dc:title";
        //String xpath = "/*/container[@parentID='0']/@parentID | /*/container[@parentID='0']/@id | /*/container[@parentID='0']/dc:title ";
        System.out.println("try jxpath now for objectid = " + objectID);
        System.out.println("this xpath " + xpath);
        
        JXPathContext context =
                JXPathContext.newContext(doc);
        
        Iterator it = context.iterate(xpath) ;
        
        return it;
        
    }
    
     
    
    
    private void PrintDom( Document doc ) {
        
        
        try {
            // Set up an identity transformer to use as serializer.
            Transformer serializer = TransformerFactory.newInstance().newTransformer();
            serializer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            String xpath = "./*";
            // Use the simple XPath API to select a nodeIterator.
            System.out.println("Querying DOM using "+xpath);
            NodeIterator nl = XPathAPI.selectNodeIterator(doc, xpath);
            
            // Serialize the found nodes to System.out.
            System.out.println("<output>");
            
            Node n;
            while ((n = nl.nextNode())!= null) {
                if (isTextNode(n)) {
                    // DOM may have more than one node corresponding to a
                    // single XPath text node.  Coalesce all contiguous text nodes
                    // at this level
                    StringBuffer sb = new StringBuffer(n.getNodeValue());
                    for (
                            Node nn = n.getNextSibling();
                    isTextNode(nn);
                    nn = nn.getNextSibling()
                    ) {
                        sb.append(nn.getNodeValue());
                    }
                    System.out.print(sb);
                } else {
                    serializer.transform(new DOMSource(n), new StreamResult(new OutputStreamWriter(System.out)));
                    
                }
                System.out.println();
            }
            System.out.println("</output>");
            
        }   catch (Exception e) {};
    }
    
    
    public static String guessContentTypeFromName(String name) {
        if (name.endsWith(".html") || name.endsWith(".htm")) {
            return "text/html";
        } else if (name.endsWith(".txt") || name.endsWith(".java")) {
            return "text/plain";
        } else if (name.endsWith(".gif")) {
            return "image/gif";
        } else if (name.endsWith(".class")) {
            return "application/octet-stream";
        } else if (name.endsWith(".jpg") || name.endsWith(".jpeg")) {
            return "image/jpeg";
        } else return "text/plain";
    }
    
    
    
} // end RequestProcessor
