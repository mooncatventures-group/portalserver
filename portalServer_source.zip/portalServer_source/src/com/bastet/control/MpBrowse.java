

package com.bastet.control;
import com.bastet.upnp.CdsObjects;
import org.cybergarage.util.*;
import org.cybergarage.xml.*;
import org.cybergarage.upnp.*;
import org.cybergarage.upnp.UPnP;
import org.cybergarage.upnp.media.player.action.BrowseAction;
import org.cybergarage.upnp.media.player.action.BrowseResult;
import org.cybergarage.upnp.media.player.action.*;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class MpBrowse extends ControlPoint {
    ////////////////////////////////////////////////
    // Constructor
    ////////////////////////////////////////////////
    
    public MpBrowse() {
    }
    
    ////////////////////////////////////////////////
    // DeviceList
    ////////////////////////////////////////////////
    
    public DeviceList getServerDeviceList() {
        DeviceList mediaServerDevList = new DeviceList();
        
        DeviceList allDevList = getDeviceList();
        int allDevCnt = allDevList.size();
        for (int n=0; n<allDevCnt; n++) {
            Device dev = allDevList.getDevice(n);
            //if (dev.isDeviceType(MediaServer.DEVICE_TYPE) == false)
            //System.out.println("device not standard");
            mediaServerDevList.add(dev);
        }
        return mediaServerDevList;
    }
    
    ////////////////////////////////////////////////
    // browse
    ////////////////////////////////////////////////
    
    public Document browse(
            Device dev,
            String objectID,
            String browseFlag,
            String filter,
            int startIndex,
            int requestedCount,
            String sortCaiteria) {
        //System.out.println("browse " + objectID + ", " + browseFlag + ", " + startIndex + ", " + requestedCount + " " + dev);
        
        if (dev == null)
            return null;
        
        Service conDir = dev.getService("urn:schemas-upnp-org:service:ContentDirectory:1");
        ServiceList servicelist = dev.getServiceList();
        if (conDir == null)
            return null;
        Action action = conDir.getAction("Browse");
        //	if (action == null)
        //		return null;
        BrowseAction browseAction = new BrowseAction(action);
        browseAction.setObjectID(objectID);
        browseAction.setBrowseFlag(browseFlag);
        browseAction.setStartingIndex(startIndex);
        browseAction.setRequestedCount(requestedCount);
        browseAction.setFilter(filter);
        browseAction.setSortCriteria(sortCaiteria);
        if (browseAction.postControlAction() == false)
            return null;
        
        Argument resultArg = browseAction.getArgument(BrowseAction.RESULT);
      
        
        if (resultArg == null)
            return null;
        
        String resultStr = resultArg.getValue();
        
        
        
        if (resultStr == null)
            return null;
        try {
            CdsObjects DomDoc = new CdsObjects(resultStr);
            return DomDoc.getDomDoc();
        } catch (Exception e) {};
        return null;
    }
    
    
    
    
    ////////////////////////////////////////////////
    // browse*
    ////////////////////////////////////////////////
    
    public Document browseMetaData(
            Device dev,
            String objectID,
            String filter,
            int startIndex,
            int requestedCount,
            String sortCaiteria) {
        return browse(dev, objectID, BrowseAction.BROWSE_METADATA, filter, startIndex, requestedCount, sortCaiteria);
    }
    
    
    public Document browseDirectChildren(
            Device dev,
            String objectID,
            String filter,
            int startIndex,
            int requestedCount,
            String sortCaiteria) {
        return browse(dev, objectID, BrowseAction.BROWSE_DIRECT_CHILDREN, filter, startIndex, requestedCount, sortCaiteria);
    }
    
    public Action FindContentDirectory(ServiceList serviceList) {
        // Check for content directory service
        
        
        
        Service service;
        
        int serviceCnt = serviceList.size();
        
        for (int n = 0; n < serviceCnt; n++) {
            service = serviceList.getService(n);
            
            System.out.println(" Service Type: " + service.getServiceType());
            System.out.println(" Service Id: " + service.getServiceID());
            System.out.println(" Service SCPD URL: " + service.getSCPDURL());
            System.out.println(" Service Control URL: " + service.getControlURL());
            
            
            
            if (service.getServiceType().indexOf("ContentDirectory") >= 0) {
                System.out.println(" Matched content director service!!!!");
                return service.getAction("Browse");
            } else
                System.out.println(" Didn't match content directory service!!!!");
        }
        return null;
    }
}












