package com.bastet.control;
import java.net.*;
import java.io.*;
import java.util.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.io.IOException;
import org.cybergarage.upnp.*;
import org.json.simple.*;

public class JsonRequest  {
    
    public JsonRequest(DeviceList upnpdevicelist , HtmlTemplate htmltemplates , Writer out) {
        
        JSONObject deviceListObj = new JSONObject( );
        JSONObject deviceObj = new JSONObject( );
        
        try {
            
            for (int i=upnpdevicelist.size()-1; i>=0; i--) {
                deviceObj.put("device", htmltemplates.cleanupServerHref(upnpdevicelist.getDevice(i).getFriendlyName()));
            }
            deviceListObj.put("devicelist", deviceObj);
            
            out.write(deviceListObj.toString() +  "\r\n");
            
        } catch (IOException ex) {
        }
    }
    
    
    
    
    
    
    public JsonRequest(Iterator it , Iterator itx , String mediaDev , Writer out) {
        String objectItemId = null;
        String objectParentId = null;
        String objectName = null;
        String objectType = null;
        
        JSONObject container = new JSONObject( );
        JSONArray  folderArray = new JSONArray();
        
        try {
            
            while(it !=null && it.hasNext()) {
                
                objectItemId =  it.next().toString();
                if (objectItemId == null){
                    objectItemId = "nokey";
                }
                
                objectParentId =  it.next().toString();
                if (objectParentId == null){
                    objectParentId = "nokey";
                }
                
                objectName =  it.next().toString();
                if (objectName == null){
                    objectName = "nokey";
                }
                
                objectType =  it.next().toString();
                if (objectType == null){
                    objectType = "unknown";
                }
                
                
    
                
                
                JSONObject folderItem = new JSONObject( );
                JSONObject folder = new JSONObject( );
                folderItem.put("itemId", objectItemId);
                folderItem.put("parentId", objectParentId);
                folderItem.put("name", objectName);
                folderItem.put("type", objectType);
                folder.put("folder" , folderItem);
                folderArray.add(folder);
                
            }
            
            container.put("container" , folderArray);
            
            out.write(container.toString() +  "\r\n");
            out.flush();
            
            
            JSONObject item = new JSONObject( );
            JSONArray  resArray = new JSONArray();
            
            
            
            while(itx !=null && itx.hasNext()) {
                
                JSONObject resItem = new JSONObject( );
                JSONObject res = new JSONObject( );
                resItem.put("name" , itx.next());
                resItem.put("media" , itx.next());
                res.put("res" , resItem);
                resArray.add(res);
                
            }
            item.put("item" , resArray);
            out.write(item.toString() +  "\r\n");
            out.flush();
        }
        
        catch (IOException ex) {
        }
    }
}

