/******************************************************************
 *
 *	CyberHTTP for Java
 *
 *	Copyright (C) Satoshi Konno 2002-2003
 *
 *	File: HTML.java
 *
 *	Revision;
 *
 *	01/05/03
 *		- first revision.
 *	
 ******************************************************************/

package org.cybergarage.http;

public class HTML
{
    public static final String CONTENT_TYPE = "text/html; charset=\"utf-8\"";
}
