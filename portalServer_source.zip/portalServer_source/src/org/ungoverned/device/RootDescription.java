/*
 * Created on 21-lug-2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package org.ungoverned.device;

/**
 * @author Kismet TODO To change the template for this generated type comment go to Window -
 *         Preferences - Java - Code Generation - Code and Comments
 */
public interface RootDescription
{

    public final String ROOT_ELEMENT           = "root";
    public final String ROOT_ELEMENT_NAMESPACE = "urn:schema-upnp-device-org:device-1-0";

    public final String SPECVERSION_ELEMENT    = "specVersion";
    public final String MAJOR_ELEMENT          = "major";
    public final String MINOR_ELEMENT          = "minor";
    public final String SERVICE_LIST_ELEMENT   = "serviceList";
}
